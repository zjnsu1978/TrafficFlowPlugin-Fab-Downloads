﻿// Copyright (c) 2026 zjnsu1978. All rights reserved.
#include "TrafficVehicleActor.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"

ATrafficVehicleActor::ATrafficVehicleActor()
{
	PrimaryActorTick.bCanEverTick = false;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	VehicleMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("VehicleMesh"));
	VehicleMesh->SetupAttachment(SceneRoot);
	VehicleMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	VehicleMesh->SetGenerateOverlapEvents(false);
	VehicleMesh->SetSimulatePhysics(false);
	VehicleMesh->SetMobility(EComponentMobility::Movable);
}

void ATrafficVehicleActor::ApplyVehicleMesh(UStaticMesh* NewMesh, FVector NewScale)
{
	if (VehicleMesh)
	{
		if (NewMesh)
		{
			VehicleMesh->SetStaticMesh(NewMesh);
		}
		VehicleMesh->SetRelativeScale3D(NewScale);
		VehicleMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		VehicleMesh->SetGenerateOverlapEvents(false);
		VehicleMesh->SetSimulatePhysics(false);
	}
}

void ATrafficVehicleActor::UpdateWheelRotation(float MovementSpeed, float DeltaSeconds)
{
	OnTrafficMovementUpdated(MovementSpeed, DeltaSeconds);

	if (!bAnimateWheels || WheelRadius <= KINDA_SMALL_NUMBER || DeltaSeconds <= 0.0f)
	{
		return;
	}

	const float DirectionSign = bInvertWheelRotation ? -1.0f : 1.0f;
	const float Degrees = FMath::RadiansToDegrees((MovementSpeed * DeltaSeconds) / WheelRadius) * DirectionSign;
	FVector SafeAxis = WheelRotationAxis.GetSafeNormal();
	if (SafeAxis.IsNearlyZero())
	{
		SafeAxis = FVector(0.0f, 1.0f, 0.0f);
	}
	const FQuat DeltaRotation(SafeAxis, FMath::DegreesToRadians(Degrees));

	TArray<USceneComponent*> ComponentsToRotate;
	for (USceneComponent* WheelComponent : WheelComponents)
	{
		if (WheelComponent)
		{
			ComponentsToRotate.Add(WheelComponent);
		}
	}

	if (ComponentsToRotate.Num() == 0 && bAutoFindWheelComponents)
	{
		TArray<UStaticMeshComponent*> StaticMeshComponents;
		GetComponents<UStaticMeshComponent>(StaticMeshComponents);
		for (UStaticMeshComponent* StaticMeshComponent : StaticMeshComponents)
		{
			if (StaticMeshComponent && StaticMeshComponent != VehicleMesh)
			{
				ComponentsToRotate.Add(StaticMeshComponent);
			}
		}
	}

	for (USceneComponent* WheelComponent : ComponentsToRotate)
	{
		if (WheelComponent)
		{
			WheelComponent->AddLocalRotation(DeltaRotation, false, nullptr, ETeleportType::TeleportPhysics);
		}
	}
}

