﻿// Copyright (c) 2026 zjnsu1978. All rights reserved.
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TrafficVehicleActor.generated.h"

UCLASS(Blueprintable)
class TRAFFICFLOW57_API ATrafficVehicleActor : public AActor
{
	GENERATED_BODY()

public:
	ATrafficVehicleActor();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Traffic|Vehicle")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Traffic|Vehicle")
	TObjectPtr<UStaticMeshComponent> VehicleMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Vehicle")
	float VehicleLength = 420.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Vehicle")
	float DesiredSpeed = 900.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels")
	bool bAnimateWheels = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels", meta = (EditCondition = "bAnimateWheels"))
	bool bAutoFindWheelComponents = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels", meta = (EditCondition = "bAnimateWheels"))
	TArray<TObjectPtr<USceneComponent>> WheelComponents;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels", meta = (EditCondition = "bAnimateWheels", ClampMin = "1.0"))
	float WheelRadius = 34.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels", meta = (EditCondition = "bAnimateWheels"))
	FVector WheelRotationAxis = FVector(0.0f, 1.0f, 0.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Wheels", meta = (EditCondition = "bAnimateWheels"))
	bool bInvertWheelRotation = false;

	UFUNCTION(BlueprintCallable, Category = "Traffic|Vehicle")
	void ApplyVehicleMesh(UStaticMesh* NewMesh, FVector NewScale);

	UFUNCTION(BlueprintCallable, Category = "Traffic|Wheels")
	void UpdateWheelRotation(float MovementSpeed, float DeltaSeconds);

	UFUNCTION(BlueprintImplementableEvent, Category = "Traffic|Vehicle")
	void OnTrafficMovementUpdated(float MovementSpeed, float DeltaSeconds);
};

