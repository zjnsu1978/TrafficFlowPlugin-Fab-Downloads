﻿// Copyright (c) 2026 zjnsu1978. All rights reserved.
using UnrealBuildTool;

public class TrafficFlow57Editor : ModuleRules
{
	public TrafficFlow57Editor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"AssetRegistry",
			"Projects"
		});
	}
}

