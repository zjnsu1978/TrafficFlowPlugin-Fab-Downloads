﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TrafficVehicleActor.h"
#include "TrafficFlowManager.generated.h"

class USplineComponent;
class UStaticMeshComponent;

USTRUCT(BlueprintType)
struct FTrafficVehicleType
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	FName Name = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	TSubclassOf<AActor> VehicleClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	TObjectPtr<UStaticMesh> VehicleMesh = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	FVector VehicleScale = FVector(1.0f, 1.0f, 1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float VehicleLength = 420.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float GroundZOffset = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float DesiredSpeed = 900.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float SpawnWeight = 1.0f;
};

USTRUCT()
struct FRuntimeTrafficVehicle
{
	GENERATED_BODY()

	UPROPERTY()
	TObjectPtr<AActor> Actor = nullptr;

	UPROPERTY()
	float Distance = 0.0f;

	UPROPERTY()
	float Speed = 900.0f;

	UPROPERTY()
	float DesiredSpeed = 900.0f;

	UPROPERTY()
	float BaseDesiredSpeed = 900.0f;

	UPROPERTY()
	float DynamicSpeedTimer = 0.0f;

	UPROPERTY()
	float VehicleLength = 420.0f;

	UPROPERTY()
	float GroundZOffset = 0.0f;

	UPROPERTY()
	int32 LaneIndex = 0;

	UPROPERTY()
	int32 HomeLaneIndex = 0;

	UPROPERTY()
	float CurrentLanePosition = 0.0f;

	UPROPERTY()
	float LaneChangeYawOffset = 0.0f;

	UPROPERTY()
	float OvertakeReturnTimer = 0.0f;

	UPROPERTY()
	float OvertakeRetryTimer = 0.0f;
};

UCLASS(Blueprintable)
class TRAFFICFLOW57_API ATrafficFlowManager : public AActor
{
	GENERATED_BODY()

public:
	ATrafficFlowManager();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "车流|路径", meta = (DisplayName = "场景根组件"))
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "车流|路径", meta = (DisplayName = "车流路径"))
	TObjectPtr<USplineComponent> TrafficPath;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "车流|预览", meta = (DisplayName = "预览根组件"))
	TObjectPtr<USceneComponent> PreviewRoot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|车辆", meta = (DisplayName = "车辆类型", ToolTip = "可生成的车辆类型列表"))
	TArray<FTrafficVehicleType> VehicleTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|车辆", meta = (DisplayName = "车辆贴地高度偏移", ToolTip = "按车辆类型列表的顺序逐项对应。飘起来填负数，陷入地面填正数。"))
	TArray<float> VehicleGroundZOffsets;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|生成", meta = (ClampMin = "1", ClampMax = "200", DisplayName = "初始车辆数量"))
	int32 InitialVehicleCount = 20;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|生成", meta = (ClampMin = "1", ClampMax = "8", DisplayName = "车道数量"))
	int32 LaneCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|生成", meta = (DisplayName = "车道间距"))
	float LaneSpacing = 420.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|生成", meta = (DisplayName = "最小车距"))
	float MinimumGap = 280.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|生成", meta = (DisplayName = "开始时生成车辆"))
	bool bSpawnOnBeginPlay = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|移动", meta = (DisplayName = "循环车流"))
	bool bLoopTraffic = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|移动", meta = (DisplayName = "反向行驶"))
	bool bReverseTrafficDirection = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|移动", meta = (DisplayName = "车辆高度偏移"))
	float VehicleZOffset = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (DisplayName = "使用随机间距"))
	bool bUseRandomSpacing = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (EditCondition = "bUseRandomSpacing", DisplayName = "随机间距最小倍率"))
	float RandomSpacingMin = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (EditCondition = "bUseRandomSpacing", DisplayName = "随机间距最大倍率"))
	float RandomSpacingMax = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (DisplayName = "使用随机速度"))
	bool bUseRandomSpeed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (EditCondition = "bUseRandomSpeed", DisplayName = "随机速度最小倍率"))
	float RandomSpeedMin = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|随机", meta = (EditCondition = "bUseRandomSpeed", DisplayName = "随机速度最大倍率"))
	float RandomSpeedMax = 1.15f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|动态速度", meta = (DisplayName = "使用动态速度变化"))
	bool bUseDynamicSpeedVariation = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|动态速度", meta = (EditCondition = "bUseDynamicSpeedVariation", DisplayName = "动态速度最小倍率"))
	float DynamicSpeedMin = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|动态速度", meta = (EditCondition = "bUseDynamicSpeedVariation", DisplayName = "动态速度最大倍率"))
	float DynamicSpeedMax = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|动态速度", meta = (EditCondition = "bUseDynamicSpeedVariation", DisplayName = "动态变速最短间隔"))
	float DynamicSpeedChangeIntervalMin = 2.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|动态速度", meta = (EditCondition = "bUseDynamicSpeedVariation", DisplayName = "动态变速最长间隔"))
	float DynamicSpeedChangeIntervalMax = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|跟车避让", meta = (DisplayName = "使用跟车避让"))
	bool bUseFollowAvoidance = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|跟车避让", meta = (EditCondition = "bUseFollowAvoidance", DisplayName = "减速距离"))
	float SlowdownDistance = 1200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|跟车避让", meta = (EditCondition = "bUseFollowAvoidance", DisplayName = "加速度"))
	float AccelerationRate = 650.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|跟车避让", meta = (EditCondition = "bUseFollowAvoidance", DisplayName = "刹车速度"))
	float BrakingRate = 2200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (DisplayName = "使用超车系统", ToolTip = "前方拥堵且旁车道安全时允许车辆变道超车"))
	bool bUseOvertaking = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", DisplayName = "超车前方检测距离"))
	float OvertakeLookAheadDistance = 900.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.05", ClampMax = "1.0", DisplayName = "拥堵速度比例"))
	float OvertakeBlockedSpeedRatio = 0.55f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0", ClampMax = "1.0", DisplayName = "超车几率"))
	float OvertakeChance = 0.65f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0", DisplayName = "超车重试间隔"))
	float OvertakeRetryInterval = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", DisplayName = "旁车道安全距离"))
	float OvertakeLaneClearanceDistance = 850.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", DisplayName = "横向变道速度"))
	float OvertakeLateralSpeed = 2.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0", ClampMax = "45.0", DisplayName = "最大转向角"))
	float OvertakeMaxSteeringYaw = 14.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.1", DisplayName = "转向响应速度"))
	float OvertakeSteeringResponse = 7.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|超车", meta = (EditCondition = "bUseOvertaking", DisplayName = "回原车道延迟"))
	float OvertakeReturnDelay = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|地形", meta = (DisplayName = "使用地形检测"))
	bool bUseTerrainDetection = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|地形", meta = (EditCondition = "bUseTerrainDetection", DisplayName = "地形检测起点高度"))
	float TerrainTraceStartHeight = 3000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|地形", meta = (EditCondition = "bUseTerrainDetection", DisplayName = "地形检测向下深度"))
	float TerrainTraceEndDepth = 6000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|地形", meta = (EditCondition = "bUseTerrainDetection", DisplayName = "地形高度偏移"))
	float TerrainZOffset = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "车流|预览", meta = (DisplayName = "显示编辑器预览"))
	bool bShowEditorPreview = true;

	UFUNCTION(BlueprintCallable, Category = "车流", meta = (DisplayName = "生成车流"))
	void SpawnTraffic();

	UFUNCTION(BlueprintCallable, Category = "车流", meta = (DisplayName = "清除车流"))
	void ClearTraffic();

	UFUNCTION(BlueprintCallable, Category = "车流", meta = (DisplayName = "推进车流"))
	void AdvanceTraffic(float DeltaSeconds);

protected:
	UPROPERTY()
	TArray<FRuntimeTrafficVehicle> RuntimeVehicles;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UStaticMeshComponent>> PreviewVehicleMeshes;

	const FTrafficVehicleType* PickVehicleType(int32 Index) const;
	void UpdateDynamicSpeedVariation(float DeltaSeconds);
	void UpdateOvertaking(float DeltaSeconds, float SplineLength);
	void UpdateAvoidanceSpeeds(float DeltaSeconds, float SplineLength);
	float GetDynamicSpeedScale(int32 VehicleIndex, float TimeSeed) const;
	float GetDynamicSpeedInterval(int32 VehicleIndex, float TimeSeed) const;
	float GetDistanceToFrontVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& FrontVehicle, float SplineLength) const;
	float GetDistanceToRearVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& RearVehicle, float SplineLength) const;
	float GetMaxMoveBeforeOverlap(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const;
	bool IsLaneClearForOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 CandidateLaneIndex, float SplineLength) const;
	int32 FindBestOvertakeLane(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const;
	bool ShouldAttemptOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 VehicleIndex, float SplineLength) const;
	void UpdateLaneChangePose(FRuntimeTrafficVehicle& RuntimeVehicle, float DeltaSeconds) const;
	void PlaceVehicle(FRuntimeTrafficVehicle& RuntimeVehicle) const;
	FVector GetLaneRightVectorAtDistance(float Distance) const;
	float GetSpacingForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type, float BaseSpacing) const;
	float GetSpeedForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type) const;
	float GetGroundZOffsetForVehicleType(int32 VehicleTypeIndex, const FTrafficVehicleType& Type) const;
	float GetSplineSampleDistance(float Distance) const;
	FRotator GetPathYawRotation(float Distance) const;
	FVector ProjectToTerrain(const FVector& Location, const AActor* ActorToIgnore = nullptr) const;
	bool FindTerrainPoint(const FVector& Location, const AActor* ActorToIgnore, FVector& OutPoint) const;
	FVector ProjectVehiclePivotToTerrain(const FVector& Location, const AActor* ActorToIgnore = nullptr) const;
	void BuildEditorPreview();
	void ClearEditorPreview();
};
