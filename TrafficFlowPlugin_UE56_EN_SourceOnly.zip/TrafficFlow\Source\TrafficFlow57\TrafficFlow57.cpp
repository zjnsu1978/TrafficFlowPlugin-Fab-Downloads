﻿// Copyright (c) 2026 zjnsu1978. All rights reserved.
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FDefaultModuleImpl, TrafficFlow57);

