﻿// Copyright (c) 2026 zjnsu1978. All rights reserved.
using UnrealBuildTool;

public class TrafficFlow57 : ModuleRules
{
	public TrafficFlow57(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore"
		});
	}
}

