﻿# Traffic Flow Plugin / 杞︽祦鎻掍欢璇存槑

UE version / UE鐗堟湰: Unreal Engine 5.8  
Plugin folder / 鎻掍欢鐩綍: `TrafficFlow`

## 涓枃璇存槑

### 1. 鎻掍欢鐢ㄩ€?
Traffic Flow 鏄竴涓熀浜庢牱鏉＄嚎鐨勮溅娴佹彃浠躲€傚畠鍙互鍦ㄥ叧鍗′腑娌?Spline 鑷姩鐢熸垚杞﹁締锛岃杞﹁締娌挎牱鏉＄嚎琛岄┒锛屽苟鏀寔杞﹁締鏇挎崲銆侀槻姝㈤噸鍙犮€佽窡杞﹀噺閫熴€侀殢鏈洪€熷害銆佸姩鎬侀€熷害鍙樺寲銆佸湴褰㈡娴嬨€佺紪杈戝櫒棰勮鍜岃疆瀛愭棆杞€?
鎻掍欢鏍稿績钃濆浘/绫伙細

- `BP_TrafficFlowManager`: 杞︽祦绠＄悊鍣紝鏀惧埌鍦烘櫙閲屼娇鐢ㄣ€?- `BP_TrafficVehicle_Sedan`: 绀轰緥杞胯溅銆?- `BP_TrafficVehicle_Van`: 绀轰緥闈㈠寘杞︺€?- `BP_TrafficVehicle_Truck`: 绀轰緥鍗¤溅銆?- `TrafficVehicleActor`: 鍙户鎵跨殑杞﹁締鍩虹被銆?
### 2. 瀹夎鏂规硶

灏嗘彃浠舵枃浠跺す澶嶅埗鍒扮洰鏍囬」鐩細

```text
YourProject/Plugins/TrafficFlow/TrafficFlow.uplugin
```

姝ｇ‘缁撴瀯搴旇鏄細

```text
YourProject
  Plugins
    TrafficFlow
      TrafficFlow.uplugin
      Binaries
      Content
      Source
```

澶嶅埗瀹屾垚鍚庯細

1. 鎵撳紑 UE5.8 椤圭洰銆?2. 鎵撳紑 `Edit > Plugins`銆?3. 鎼滅储 `Traffic Flow`銆?4. 鍚敤鎻掍欢銆?5. 鎸夋彁绀洪噸鍚紪杈戝櫒銆?
濡傛灉鍐呭娴忚鍣ㄩ噷鐪嬩笉鍒版彃浠跺唴瀹癸細

1. 鎵撳紑 Content Browser 鍙充笂瑙掕缃€?2. 鍕鹃€?`Show Plugin Content` / `鏄剧ず鎻掍欢鍐呭`銆?3. 鍦?`All > Plugins > TrafficFlow` 涓嬫煡鎵捐摑鍥俱€?4. 涔熷彲浠ョ洿鎺ユ悳绱?`BP_TrafficFlowManager`銆?
### 3. 蹇€熶娇鐢?
1. 鍦ㄥ唴瀹规祻瑙堝櫒涓壘鍒?`BP_TrafficFlowManager`銆?2. 鎷栧叆鍏冲崱銆?3. 閫変腑鍦烘櫙涓殑 `BP_TrafficFlowManager`銆?4. 鍦ㄧ粏鑺傞潰鏉胯皟鏁?`TrafficPath` 鏍锋潯绾跨偣銆?5. 璁剧疆杞﹁締鏁伴噺銆佽溅閬撴暟閲忋€侀€熷害銆侀棿璺濈瓑鍙傛暟銆?6. 鐐瑰嚮鎾斁锛岃溅杈嗕細娌挎牱鏉＄嚎绉诲姩銆?
榛樿鏍锋潯绾挎槸涓嶉棴鍚堢殑銆傚鏋滈渶瑕佸惊鐜溅娴侊紝寮€鍚?`Loop Traffic`銆?
### 4. 璺緞鍜屾柟鍚?
杞﹁締娌?`TrafficPath` 鏍锋潯绾跨Щ鍔ㄣ€傜Щ鍔ㄦ柟鍚戠敱鏍锋潯绾跨偣鐨勯『搴忓喅瀹氥€?
甯哥敤鍙傛暟锛?
- `Loop Traffic`: 鍒拌揪缁堢偣鍚庡惊鐜洖璧风偣銆?- `Reverse Traffic Direction`: 鍙嶅悜琛岄┒銆?- `VehicleZOffset`: 杞﹁締鐩稿鏍锋潯绾跨殑楂樺害鍋忕Щ锛岄粯璁?`0`銆?- `Lane Count`: 杞﹂亾鏁伴噺銆?- `Lane Spacing`: 杞﹂亾闂磋窛銆?
濡傛灉杞﹁締鏂瑰悜鍙嶄簡锛屼紭鍏堝垏鎹?`Reverse Traffic Direction`銆?
濡傛灉杞﹁締鎮┖鎴栧煁鍏ュ湴闈紝璋冩暣 `VehicleZOffset` 鎴栧紑鍚湴褰㈡娴嬪悗璋冩暣 `TerrainZOffset`銆?
### 5. 鏇挎崲杞﹁締

鍦?`BP_TrafficFlowManager` 鐨?`Vehicle Types` 涓坊鍔犳垨淇敼杞﹁締绫诲瀷銆?
姣忎釜杞﹁締绫诲瀷鍖呭惈锛?
- `Name`: 杞﹁締绫诲瀷鍚嶇О銆?- `Vehicle Class`: 瑕佺敓鎴愮殑杞﹁締 Actor 钃濆浘绫汇€?- `Vehicle Mesh`: 浣跨敤鎻掍欢榛樿杞﹁締鍩虹被鏃讹紝鍙浛鎹㈤潤鎬佺綉鏍笺€?- `Vehicle Scale`: 杞﹁締缂╂斁锛岄粯璁ゅ缓璁繚鎸?`1, 1, 1`銆?- `Vehicle Length`: 杞﹁締闀垮害锛岀敤浜庨棿璺濆拰闃查噸鍙犺绠椼€?- `Desired Speed`: 鐩爣閫熷害銆?- `Spawn Weight`: 鐢熸垚鏉冮噸銆?
`Vehicle Class` 鐜板湪鍙互閫夋嫨浠绘剰 `Actor` 钃濆浘绫汇€? 
濡傛灉璇ヨ摑鍥剧户鎵胯嚜 `TrafficVehicleActor`锛屾彃浠朵細棰濆鏀寔鑷姩鎹?Mesh銆佽疆瀛愭棆杞€佽溅杈嗛暱搴﹀拰閫熷害鍙傛暟鍚屾銆? 
濡傛灉鏄櫘閫?Actor 钃濆浘锛屾彃浠朵細绉诲姩鏁翠釜 Actor锛屼絾涓嶄細鑷姩鏇挎崲 Mesh锛屼篃涓嶄細鑷姩璇嗗埆 `TrafficVehicleActor` 鐨勮溅杈嗗弬鏁般€?
### 6. 闃叉杞﹁締閲嶅彔

鎻掍欢閫氳繃璺熻溅閬胯绯荤粺閬垮厤杞﹁締閲嶅彔銆?
鐩稿叧鍙傛暟锛?
- `Use Follow Avoidance`: 鍚敤璺熻溅閬胯銆?- `Minimum Gap`: 杞﹁締涔嬮棿鐨勬渶灏忛棿璺濄€?- `Slowdown Distance`: 鍓嶆柟杞﹁締杩涘叆璇ヨ寖鍥村悗寮€濮嬪噺閫熴€?- `Braking Rate`: 鍒硅溅閫熷害銆?- `Acceleration Rate`: 鎭㈠鍔犻€熼€熷害銆?
寤鸿淇濇寔 `Use Follow Avoidance` 寮€鍚€? 
濡傛灉杞﹁締浠嶇劧澶繎锛屽澶?`Minimum Gap` 鎴?`Slowdown Distance`銆? 
濡傛灉鍑忛€熷お鎱紝澧炲ぇ `Braking Rate`銆?
### 7. 闅忔満闂磋窛鍜岄殢鏈洪€熷害

鐢熸垚鏃堕殢鏈猴細

- `Use Random Spacing`: 姣忚締杞︾敓鎴愰棿璺濋殢鏈恒€?- `Random Spacing Min / Max`: 闂磋窛鍊嶇巼鑼冨洿銆?- `Use Random Speed`: 姣忚締杞︾敓鎴愭椂閫熷害闅忔満銆?- `Random Speed Min / Max`: 鍒濆閫熷害鍊嶇巼鑼冨洿銆?
杩愯涓殢鏈哄彉閫燂細

- `Use Dynamic Speed Variation`: 鍚敤鍗曡溅杩愯涓殢鏈哄彉閫熴€?- `Dynamic Speed Min / Max`: 鍔ㄦ€侀€熷害鍊嶇巼鑼冨洿銆?- `Dynamic Speed Change Interval Min / Max`: 姣忚締杞﹂殢鏈烘崲閫熷害鐨勬椂闂撮棿闅斻€?
绀轰緥锛? 
`Dynamic Speed Min = 0.75`锛宍Dynamic Speed Max = 1.25` 琛ㄧず杞﹁締杩愯涓細鍦ㄥ熀纭€閫熷害鐨?75% 鍒?125% 涔嬮棿鍙樺寲銆?
### 8. 鍦板舰妫€娴?
鍦板舰妫€娴嬪彲浠ヨ杞﹁締璐村悎鍦伴潰楂樺害銆?
鐩稿叧鍙傛暟锛?
- `Use Terrain Detection`: 寮€鍚湴褰㈡娴嬨€?- `Terrain Trace Start Height`: 鍚戜笂杩借釜璧风偣楂樺害銆?- `Terrain Trace End Depth`: 鍚戜笅杩借釜娣卞害銆?- `TerrainZOffset`: 鍛戒腑鍦伴潰鍚庣殑楂樺害鍋忕Щ锛岄粯璁?`0`銆?
濡傛灉杞﹁締鍙渶瑕佷弗鏍艰创鍚堟牱鏉＄嚎锛屽彲浠ュ叧闂湴褰㈡娴嬨€? 
濡傛灉鍦烘櫙鏈夎捣浼忓湴褰紝鍙互寮€鍚湴褰㈡娴嬨€?
### 9. 缂栬緫鍣ㄩ瑙?
`Show Editor Preview` 寮€鍚悗锛屼笉杩愯娓告垙涔熻兘鐪嬪埌澶ц嚧杞﹁締鍒嗗竷銆?
娉ㄦ剰锛?
- 缂栬緫鍣ㄩ瑙堜富瑕佺敤浜庢煡鐪嬩綅缃拰瀵嗗害銆?- 棰勮浣跨敤 `Vehicle Mesh` 鏄剧ず闈欐€佽溅杈嗐€?- 杩愯鏃跺鏋滀娇鐢ㄧ殑鏄嚜瀹氫箟 `Vehicle Class`锛屽疄闄呯敓鎴愮粨鏋滀互杩愯鏃朵负鍑嗐€?
### 10. 杞瓙鏃嬭浆

杞﹁締钃濆浘缁ф壙鑷?`TrafficVehicleActor` 鏃讹紝鍙互浣跨敤鑷姩杞瓙鏃嬭浆銆?
鍙傛暟浣嶄簬杞﹁締钃濆浘鐨?`Wheels` 鍒嗙被锛?
- `Animate Wheels`: 寮€鍚疆瀛愭棆杞€?- `Auto Find Wheel Components`: 鑷姩鏌ユ壘杞瓙缁勪欢銆?- `Wheel Components`: 鎵嬪姩鎸囧畾杞瓙缁勪欢锛屽彲閫夈€?- `Wheel Radius`: 杞瓙鍗婂緞锛屽奖鍝嶈浆閫熴€?- `Wheel Rotation Axis`: 杞瓙鏃嬭浆杞淬€?- `Invert Wheel Rotation`: 杞瓙杞弽鏃跺惎鐢ㄣ€?
鎺ㄨ崘鐢ㄦ硶锛?
1. 杞﹁締钃濆浘缁ф壙 `TrafficVehicleActor`銆?2. 杞﹁韩涓轰富 `VehicleMesh`銆?3. 鍥涗釜杞瓙鏄嫭绔嬬殑 Static Mesh 瀛愮粍浠躲€?4. 淇濇寔 `Animate Wheels` 鍜?`Auto Find Wheel Components` 寮€鍚€?5. 鎾斁娴嬭瘯銆?
濡傛灉杞瓙杞弽锛屽紑鍚?`Invert Wheel Rotation`銆? 
濡傛灉杞瓙缁曢敊杞存棆杞紝灏濊瘯浠ヤ笅杞达細

```text
0, 1, 0
1, 0, 0
0, 0, 1
```

濡傛灉杞﹁締鏄竴涓畬鏁寸殑鍗曚綋 Static Mesh锛岃溅杞病鏈夌嫭绔嬬粍浠讹紝鍒欐彃浠朵笉鑳藉崟鐙棆杞疆瀛愩€傞渶瑕佸皢杞﹁韩鍜岃疆瀛愭媶鎴愮嫭绔嬬粍浠讹紝鎴栦娇鐢ㄥ甫楠ㄩ/鍔ㄧ敾鐨勮溅杈嗚摑鍥俱€?
### 11. 鏅€氳溅杈?Actor 鍜?Cinematic Car Rig

`Vehicle Class` 鍙互閫夋嫨鏅€?Actor锛屼緥濡?Cinematic Car Rig 钃濆浘銆? 
杩欑鎯呭喌涓嬶紝鎻掍欢浼氭部鏍锋潯绾跨Щ鍔ㄦ暣涓?Actor銆?
闇€瑕佹敞鎰忥細

- 鏅€?Actor 涓嶄細鑷姩搴旂敤 `Vehicle Mesh`銆?- 鏅€?Actor 涓嶄細鑷姩浣跨敤 `TrafficVehicleActor` 鐨勮疆瀛愭棆杞弬鏁般€?- 濡傛灉璇?Actor 鑷甫鍔ㄧ敾鎴栬溅杞帶鍒讹紝闇€瑕佸湪鑷繁鐨勮摑鍥鹃噷澶勭悊銆?- 鎻掍欢鎻愪緵 `OnTrafficMovementUpdated` 浜嬩欢缁?`TrafficVehicleActor` 瀛愮被浣跨敤锛屽鏉傝摑鍥惧彲浠ュ湪璇ヤ簨浠朵腑椹卞姩杞﹁疆鍔ㄧ敾銆?
### 12. 甯歌闂

#### 鎻掍欢鍚敤浜嗭紝浣嗗唴瀹归噷娌℃湁 TrafficFlow 鏂囦欢澶?
寮€鍚?`Show Plugin Content` / `鏄剧ず鎻掍欢鍐呭`銆傛彃浠跺唴瀹逛笉浼氶粯璁ゆ樉绀哄湪椤圭洰 `/Game` 鍐呭涓紝鑰屾槸鍦ㄦ彃浠跺唴瀹圭洰褰曚笅銆?
#### 杞﹁締涓嶆樉绀?
妫€鏌ワ細

- `Vehicle Types` 鏄惁鑷冲皯鏈変竴涓厓绱犮€?- `Vehicle Class` 鏄惁鏈夋晥銆?- 濡傛灉浣跨敤棰勮锛屾槸鍚﹁缃簡 `Vehicle Mesh`銆?- 杩愯鏃舵槸鍚﹀紑鍚簡 `Spawn On Begin Play`銆?- 杞﹁締钃濆浘鏈韩鏄惁鏈夊彲瑙?Mesh銆?
#### 杞﹁締鏂瑰悜涓嶅

灏濊瘯寮€鍚垨鍏抽棴 `Reverse Traffic Direction`銆? 
涔熷彲浠ヨ皟鏁存牱鏉＄嚎鐐圭殑椤哄簭銆?
#### 杞﹁締寰€ Z 杞撮

纭繚杞﹁締 Mesh 涓嶄娇鐢ㄧ墿鐞嗘ā鎷熴€傛彃浠堕粯璁よ溅杈嗗熀绫讳細绂佺敤纰版挒鍜岀墿鐞嗐€? 
濡傛灉浣跨敤鑷畾涔夎溅杈嗚摑鍥撅紝寤鸿鍏抽棴杞﹁締涓讳綋鐨勭墿鐞嗘ā鎷燂紝閬垮厤涓庡満鏅鎾炲悗琚墿鐞嗘帹椋炪€?
#### 杞﹁締閲嶅彔

寮€鍚?`Use Follow Avoidance`銆? 
澧炲ぇ `Minimum Gap`銆乣Slowdown Distance` 鎴?`Braking Rate`銆? 
鍚屾椂纭 `Vehicle Length` 鎺ヨ繎瀹為檯杞﹁締闀垮害銆?
#### 杞瓙涓嶈浆

妫€鏌ワ細

- 杞﹁締鏄惁缁ф壙鑷?`TrafficVehicleActor`銆?- `Animate Wheels` 鏄惁寮€鍚€?- 鏄惁鏈夌嫭绔嬭疆瀛?Static Mesh 缁勪欢銆?- `Auto Find Wheel Components` 鏄惁寮€鍚€?- `Wheel Radius` 鏄惁鍚堢悊銆?
#### 杞瓙杞緱澶揩鎴栧お鎱?
璋冩暣 `Wheel Radius`銆? 
鍗婂緞瓒婂ぇ锛岃浆寰楄秺鎱紱鍗婂緞瓒婂皬锛岃浆寰楄秺蹇€?
### 13. 鍙傛暟寤鸿

鏅€氶亾璺細

```text
Initial Vehicle Count: 20
Lane Count: 2
Lane Spacing: 420
Minimum Gap: 280
Desired Speed: 900
Slowdown Distance: 1200
Acceleration Rate: 650
Braking Rate: 2200
```

瀵嗛泦杞︽祦锛?
```text
Minimum Gap: 180 - 260
Slowdown Distance: 800 - 1200
Braking Rate: 2500 - 3500
Use Dynamic Speed Variation: true
Dynamic Speed Min: 0.75
Dynamic Speed Max: 1.15
```

鏇磋嚜鐒剁殑杞︽祦锛?
```text
Use Random Spacing: true
Random Spacing Min: 0.85
Random Spacing Max: 1.25
Use Random Speed: true
Random Speed Min: 0.85
Random Speed Max: 1.15
Use Dynamic Speed Variation: true
```

### 14. Overtaking / Lane Change Passing

Version 1.1.0 adds a runtime overtaking system. When a vehicle is held up by a slow or stopped vehicle ahead, it checks adjacent lanes. If the side lane has enough front and rear clearance, the vehicle changes lanes smoothly, passes the blockage, waits briefly, and then returns to its original lane when safe.

New settings on `BP_TrafficFlowManager`:

- `Use Overtaking`: Enables lane-change overtaking.
- `Overtake Look Ahead Distance`: How far ahead a vehicle checks for a slow blocker.
- `Overtake Blocked Speed Ratio`: A front vehicle below this fraction of the follower desired speed counts as blocked traffic.
- `Overtake Chance`: Probability that a vehicle will attempt overtaking after the road ahead is blocked and a side lane is available.
- `Overtake Retry Interval`: Cooldown before the same vehicle rolls another overtaking attempt.
- `Overtake Lane Clearance Distance`: Required clear distance in the target lane, both ahead and behind.
- `Overtake Lateral Speed`: Lane-change interpolation speed. Higher values change lanes faster.
- `Overtake Max Steering Yaw`: Maximum temporary steering angle while changing lanes.
- `Overtake Steering Response`: How quickly the vehicle points into the lane change and returns straight.
- `Overtake Return Delay`: Minimum time to stay in the passing lane before trying to return.

Recommended starting values:

```text
Use Overtaking: true
Overtake Look Ahead Distance: 900
Overtake Blocked Speed Ratio: 0.55
Overtake Chance: 0.65
Overtake Retry Interval: 1.25
Overtake Lane Clearance Distance: 850
Overtake Lateral Speed: 2.5
Overtake Max Steering Yaw: 14
Overtake Steering Response: 7
Overtake Return Delay: 1.5
```

For busy traffic, increase `Overtake Lane Clearance Distance` to reduce close cut-ins. For more aggressive traffic, lower it slightly and increase `Overtake Lateral Speed`. Lower `Overtake Chance` if too many vehicles overtake; raise it toward `1.0` if almost every capable vehicle should pass. If lane changes still look too flat, increase `Overtake Max Steering Yaw`; if the heading snaps too fast, lower `Overtake Steering Response`.

## English Guide

### 1. Overview

Traffic Flow is a spline-based traffic plugin for Unreal Engine 5.8. It spawns vehicles along a spline path, moves them along the route, and supports replaceable vehicles, no-overlap following behavior, random spacing, random speed, dynamic speed variation, terrain projection, editor preview, and wheel rotation.

Main assets/classes:

- `BP_TrafficFlowManager`: Place this actor in the level to create traffic.
- `BP_TrafficVehicle_Sedan`: Example sedan vehicle.
- `BP_TrafficVehicle_Van`: Example van vehicle.
- `BP_TrafficVehicle_Truck`: Example truck vehicle.
- `TrafficVehicleActor`: Base vehicle class for custom traffic vehicles.

### 2. Installation

Copy the plugin folder into your project:

```text
YourProject/Plugins/TrafficFlow/TrafficFlow.uplugin
```

The correct folder layout is:

```text
YourProject
  Plugins
    TrafficFlow
      TrafficFlow.uplugin
      Binaries
      Content
      Source
```

Then:

1. Open the UE5.8 project.
2. Open `Edit > Plugins`.
3. Search for `Traffic Flow`.
4. Enable the plugin.
5. Restart the editor when prompted.

If you cannot see the plugin assets in the Content Browser:

1. Open the Content Browser settings.
2. Enable `Show Plugin Content`.
3. Look under `All > Plugins > TrafficFlow`.
4. You can also search for `BP_TrafficFlowManager`.

### 3. Quick Start

1. Find `BP_TrafficFlowManager` in the Content Browser.
2. Drag it into the level.
3. Select it in the level.
4. Edit the `TrafficPath` spline points.
5. Set vehicle count, lanes, speed, and spacing.
6. Press Play. Vehicles will move along the spline.

The default spline is open, not closed. Enable `Loop Traffic` if you want vehicles to loop back to the start.

### 4. Path and Direction

Vehicles follow the `TrafficPath` spline. The movement direction is based on the spline point order.

Common settings:

- `Loop Traffic`: Wrap vehicles back to the start when they reach the end.
- `Reverse Traffic Direction`: Reverse vehicle movement direction.
- `VehicleZOffset`: Height offset from the spline, default `0`.
- `Lane Count`: Number of lanes.
- `Lane Spacing`: Distance between lanes.

If vehicles face the wrong direction, toggle `Reverse Traffic Direction`.  
If vehicles float or sink, adjust `VehicleZOffset`, or use terrain detection and adjust `TerrainZOffset`.

### 5. Replacing Vehicles

Edit `Vehicle Types` on `BP_TrafficFlowManager`.

Each vehicle type contains:

- `Name`: Vehicle type name.
- `Vehicle Class`: Actor blueprint class to spawn.
- `Vehicle Mesh`: Static mesh used by the default traffic vehicle base class.
- `Vehicle Scale`: Vehicle scale. Keeping `1, 1, 1` is recommended.
- `Vehicle Length`: Used for spacing and no-overlap calculations.
- `Desired Speed`: Target movement speed.
- `Spawn Weight`: Spawn probability weight.

`Vehicle Class` accepts any `Actor` blueprint class.  
If the class inherits from `TrafficVehicleActor`, the plugin can also apply mesh replacement, wheel animation, vehicle length, and speed settings.  
If it is a regular Actor, the plugin moves the whole Actor along the spline, but it will not automatically apply `Vehicle Mesh` or `TrafficVehicleActor` features.

### 6. Avoiding Overlap

The plugin includes a follow-avoidance system.

Settings:

- `Use Follow Avoidance`: Enables follow avoidance.
- `Minimum Gap`: Minimum distance between vehicles.
- `Slowdown Distance`: Distance at which a vehicle starts slowing down behind another vehicle.
- `Braking Rate`: How quickly vehicles slow down.
- `Acceleration Rate`: How quickly vehicles accelerate back to target speed.

Keep `Use Follow Avoidance` enabled for normal use.  
If vehicles are too close, increase `Minimum Gap` or `Slowdown Distance`.  
If braking is too slow, increase `Braking Rate`.

### 7. Random Spacing and Speed

Spawn-time randomization:

- `Use Random Spacing`: Randomizes initial spacing.
- `Random Spacing Min / Max`: Spacing multiplier range.
- `Use Random Speed`: Randomizes initial vehicle speed.
- `Random Speed Min / Max`: Initial speed multiplier range.

Runtime dynamic speed variation:

- `Use Dynamic Speed Variation`: Enables per-vehicle runtime speed changes.
- `Dynamic Speed Min / Max`: Runtime speed multiplier range.
- `Dynamic Speed Change Interval Min / Max`: Random time interval before each vehicle picks a new target speed.

Example:  
`Dynamic Speed Min = 0.75` and `Dynamic Speed Max = 1.25` means each vehicle can vary between 75% and 125% of its base speed while running.

### 8. Terrain Detection

Terrain detection projects vehicles onto ground height.

Settings:

- `Use Terrain Detection`: Enables ground projection.
- `Terrain Trace Start Height`: Trace start height above the vehicle position.
- `Terrain Trace End Depth`: Trace depth below the vehicle position.
- `TerrainZOffset`: Height offset after a ground hit, default `0`.

Keep it off if vehicles should strictly follow the spline height.  
Enable it for uneven terrain.

### 9. Editor Preview

Enable `Show Editor Preview` to see approximate vehicle placement without pressing Play.

Notes:

- Editor preview is for layout and density checking.
- Preview uses `Vehicle Mesh`.
- Runtime spawning may differ if you use a custom `Vehicle Class`.

### 10. Wheel Rotation

Vehicles that inherit from `TrafficVehicleActor` can use automatic wheel rotation.

Settings on the vehicle blueprint:

- `Animate Wheels`: Enables wheel rotation.
- `Auto Find Wheel Components`: Automatically finds wheel components.
- `Wheel Components`: Optional manual wheel component list.
- `Wheel Radius`: Wheel radius. This affects rotation speed.
- `Wheel Rotation Axis`: Local wheel rotation axis.
- `Invert Wheel Rotation`: Enable if wheels spin backward.

Recommended setup:

1. Inherit the vehicle blueprint from `TrafficVehicleActor`.
2. Use `VehicleMesh` as the main body mesh.
3. Add four independent Static Mesh components for the wheels.
4. Keep `Animate Wheels` and `Auto Find Wheel Components` enabled.
5. Press Play to test.

If wheels spin backward, enable `Invert Wheel Rotation`.  
If they rotate around the wrong axis, try:

```text
0, 1, 0
1, 0, 0
0, 0, 1
```

If the vehicle is a single static mesh with wheels merged into the body, the plugin cannot rotate the wheels separately. Split the wheels into separate components or use a skeletal/animated vehicle blueprint.

### 11. Regular Actors and Cinematic Car Rig

`Vehicle Class` can be a regular Actor, including a Cinematic Car Rig blueprint.  
In this case, the plugin moves the whole Actor along the spline.

Notes:

- Regular Actors do not automatically use `Vehicle Mesh`.
- Regular Actors do not automatically use `TrafficVehicleActor` wheel settings.
- If the Actor has its own wheel animation or rig logic, handle it inside that blueprint.
- `TrafficVehicleActor` subclasses can use the `OnTrafficMovementUpdated` event for custom animation logic.

### 12. FAQ

#### The plugin is enabled, but I cannot see the TrafficFlow folder

Enable `Show Plugin Content` in the Content Browser. Plugin assets are stored under plugin content, not under the project `/Game` folder by default.

#### Vehicles do not appear

Check:

- `Vehicle Types` has at least one entry.
- `Vehicle Class` is valid.
- `Vehicle Mesh` is assigned if you rely on editor preview.
- `Spawn On Begin Play` is enabled for runtime spawning.
- The vehicle blueprint has a visible mesh.

#### Vehicles face the wrong direction

Toggle `Reverse Traffic Direction`, or change the spline point order.

#### Vehicles fly upward on collision

Disable physics simulation on custom vehicle meshes. The default plugin vehicle class disables collision and physics to avoid physics impulses.

#### Vehicles overlap

Enable `Use Follow Avoidance`.  
Increase `Minimum Gap`, `Slowdown Distance`, or `Braking Rate`.  
Make sure `Vehicle Length` roughly matches the real vehicle length.

#### Wheels do not rotate

Check:

- The vehicle inherits from `TrafficVehicleActor`.
- `Animate Wheels` is enabled.
- The wheels are independent Static Mesh components.
- `Auto Find Wheel Components` is enabled.
- `Wheel Radius` is reasonable.

#### Wheels spin too fast or too slowly

Adjust `Wheel Radius`.  
A larger radius makes wheels spin slower. A smaller radius makes them spin faster.

### 13. Suggested Settings

Normal road:

```text
Initial Vehicle Count: 20
Lane Count: 2
Lane Spacing: 420
Minimum Gap: 280
Desired Speed: 900
Slowdown Distance: 1200
Acceleration Rate: 650
Braking Rate: 2200
```

Dense traffic:

```text
Minimum Gap: 180 - 260
Slowdown Distance: 800 - 1200
Braking Rate: 2500 - 3500
Use Dynamic Speed Variation: true
Dynamic Speed Min: 0.75
Dynamic Speed Max: 1.15
```

More natural traffic:

```text
Use Random Spacing: true
Random Spacing Min: 0.85
Random Spacing Max: 1.25
Use Random Speed: true
Random Speed Min: 0.85
Random Speed Max: 1.15
Use Dynamic Speed Variation: true
```

