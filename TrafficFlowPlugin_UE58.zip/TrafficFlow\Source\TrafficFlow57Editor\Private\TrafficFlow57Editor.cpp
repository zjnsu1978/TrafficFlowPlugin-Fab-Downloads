#include "AssetRegistry/AssetRegistryModule.h"
#include "HAL/FileManager.h"
#include "HAL/PlatformFileManager.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "Modules/ModuleManager.h"

class FTrafficFlow57EditorModule : public IModuleInterface
{
public:
	virtual void StartupModule() override
	{
		CopyContentToProject();
	}

private:
	void CopyContentToProject() const
	{
		const TSharedPtr<IPlugin> Plugin = IPluginManager::Get().FindPlugin(TEXT("TrafficFlow"));
		if (!Plugin.IsValid())
		{
			return;
		}

		const FString SourceDir = FPaths::Combine(Plugin->GetContentDir(), TEXT("TrafficFlow"));
		const FString DestDir = FPaths::Combine(FPaths::ProjectContentDir(), TEXT("TrafficFlow"));

		if (!FPaths::DirectoryExists(SourceDir))
		{
			return;
		}

		IFileManager::Get().MakeDirectory(*DestDir, true);
		FPlatformFileManager::Get().GetPlatformFile().CopyDirectoryTree(*DestDir, *SourceDir, false);

		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		TArray<FString> PathsToScan;
		PathsToScan.Add(TEXT("/Game/TrafficFlow"));
		AssetRegistryModule.Get().ScanPathsSynchronous(PathsToScan, true);
	}
};

IMPLEMENT_MODULE(FTrafficFlow57EditorModule, TrafficFlow57Editor)
