#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "TrafficVehicleActor.h"
#include "TrafficFlowManager.generated.h"

class USplineComponent;
class UStaticMeshComponent;

USTRUCT(BlueprintType)
struct FTrafficVehicleType
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	FName Name = NAME_None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	TSubclassOf<AActor> VehicleClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	TObjectPtr<UStaticMesh> VehicleMesh = nullptr;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	FVector VehicleScale = FVector(1.0f, 1.0f, 1.0f);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float VehicleLength = 420.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float DesiredSpeed = 900.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic")
	float SpawnWeight = 1.0f;
};

USTRUCT()
struct FRuntimeTrafficVehicle
{
	GENERATED_BODY()

	UPROPERTY()
	TObjectPtr<AActor> Actor = nullptr;

	UPROPERTY()
	float Distance = 0.0f;

	UPROPERTY()
	float Speed = 900.0f;

	UPROPERTY()
	float DesiredSpeed = 900.0f;

	UPROPERTY()
	float BaseDesiredSpeed = 900.0f;

	UPROPERTY()
	float DynamicSpeedTimer = 0.0f;

	UPROPERTY()
	float VehicleLength = 420.0f;

	UPROPERTY()
	int32 LaneIndex = 0;

	UPROPERTY()
	int32 HomeLaneIndex = 0;

	UPROPERTY()
	float CurrentLanePosition = 0.0f;

	UPROPERTY()
	float LaneChangeYawOffset = 0.0f;

	UPROPERTY()
	float OvertakeReturnTimer = 0.0f;

	UPROPERTY()
	float OvertakeRetryTimer = 0.0f;
};

UCLASS(Blueprintable)
class TRAFFICFLOW57_API ATrafficFlowManager : public AActor
{
	GENERATED_BODY()

public:
	ATrafficFlowManager();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Traffic|Path")
	TObjectPtr<USceneComponent> SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Traffic|Path")
	TObjectPtr<USplineComponent> TrafficPath;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Traffic|Preview")
	TObjectPtr<USceneComponent> PreviewRoot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Vehicles")
	TArray<FTrafficVehicleType> VehicleTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Spawn", meta = (ClampMin = "1", ClampMax = "200"))
	int32 InitialVehicleCount = 20;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Spawn", meta = (ClampMin = "1", ClampMax = "8"))
	int32 LaneCount = 2;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Spawn")
	float LaneSpacing = 420.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Spawn")
	float MinimumGap = 280.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Spawn")
	bool bSpawnOnBeginPlay = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	bool bLoopTraffic = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	bool bReverseTrafficDirection = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	float VehicleZOffset = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	bool bUseRandomSpacing = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseRandomSpacing"))
	float RandomSpacingMin = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseRandomSpacing"))
	float RandomSpacingMax = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	bool bUseRandomSpeed = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseRandomSpeed"))
	float RandomSpeedMin = 0.85f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseRandomSpeed"))
	float RandomSpeedMax = 1.15f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement")
	bool bUseDynamicSpeedVariation = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseDynamicSpeedVariation"))
	float DynamicSpeedMin = 0.75f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseDynamicSpeedVariation"))
	float DynamicSpeedMax = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseDynamicSpeedVariation"))
	float DynamicSpeedChangeIntervalMin = 2.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Movement", meta = (EditCondition = "bUseDynamicSpeedVariation"))
	float DynamicSpeedChangeIntervalMax = 5.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Avoidance")
	bool bUseFollowAvoidance = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Avoidance", meta = (EditCondition = "bUseFollowAvoidance"))
	float SlowdownDistance = 1200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Avoidance", meta = (EditCondition = "bUseFollowAvoidance"))
	float AccelerationRate = 650.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Avoidance", meta = (EditCondition = "bUseFollowAvoidance"))
	float BrakingRate = 2200.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking")
	bool bUseOvertaking = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking"))
	float OvertakeLookAheadDistance = 900.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.05", ClampMax = "1.0"))
	float OvertakeBlockedSpeedRatio = 0.55f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0", ClampMax = "1.0"))
	float OvertakeChance = 0.65f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0"))
	float OvertakeRetryInterval = 1.25f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking"))
	float OvertakeLaneClearanceDistance = 850.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking"))
	float OvertakeLateralSpeed = 2.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.0", ClampMax = "45.0"))
	float OvertakeMaxSteeringYaw = 14.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking", ClampMin = "0.1"))
	float OvertakeSteeringResponse = 7.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Overtaking", meta = (EditCondition = "bUseOvertaking"))
	float OvertakeReturnDelay = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Terrain")
	bool bUseTerrainDetection = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Terrain", meta = (EditCondition = "bUseTerrainDetection"))
	float TerrainTraceStartHeight = 3000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Terrain", meta = (EditCondition = "bUseTerrainDetection"))
	float TerrainTraceEndDepth = 6000.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Terrain", meta = (EditCondition = "bUseTerrainDetection"))
	float TerrainZOffset = 0.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Traffic|Preview")
	bool bShowEditorPreview = true;

	UFUNCTION(BlueprintCallable, Category = "Traffic")
	void SpawnTraffic();

	UFUNCTION(BlueprintCallable, Category = "Traffic")
	void ClearTraffic();

	UFUNCTION(BlueprintCallable, Category = "Traffic")
	void AdvanceTraffic(float DeltaSeconds);

protected:
	UPROPERTY()
	TArray<FRuntimeTrafficVehicle> RuntimeVehicles;

	UPROPERTY(Transient)
	TArray<TObjectPtr<UStaticMeshComponent>> PreviewVehicleMeshes;

	const FTrafficVehicleType* PickVehicleType(int32 Index) const;
	void UpdateDynamicSpeedVariation(float DeltaSeconds);
	void UpdateOvertaking(float DeltaSeconds, float SplineLength);
	void UpdateAvoidanceSpeeds(float DeltaSeconds, float SplineLength);
	float GetDynamicSpeedScale(int32 VehicleIndex, float TimeSeed) const;
	float GetDynamicSpeedInterval(int32 VehicleIndex, float TimeSeed) const;
	float GetDistanceToFrontVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& FrontVehicle, float SplineLength) const;
	float GetDistanceToRearVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& RearVehicle, float SplineLength) const;
	float GetMaxMoveBeforeOverlap(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const;
	bool IsLaneClearForOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 CandidateLaneIndex, float SplineLength) const;
	int32 FindBestOvertakeLane(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const;
	bool ShouldAttemptOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 VehicleIndex, float SplineLength) const;
	void UpdateLaneChangePose(FRuntimeTrafficVehicle& RuntimeVehicle, float DeltaSeconds) const;
	void PlaceVehicle(FRuntimeTrafficVehicle& RuntimeVehicle) const;
	FVector GetLaneRightVectorAtDistance(float Distance) const;
	float GetSpacingForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type, float BaseSpacing) const;
	float GetSpeedForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type) const;
	float GetSplineSampleDistance(float Distance) const;
	FRotator GetPathYawRotation(float Distance) const;
	FVector ProjectToTerrain(const FVector& Location, const AActor* ActorToIgnore = nullptr) const;
	void BuildEditorPreview();
	void ClearEditorPreview();
};
