#include "TrafficFlowManager.h"
#include "Components/SplineComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/EngineTypes.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"

ATrafficFlowManager::ATrafficFlowManager()
{
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SetRootComponent(SceneRoot);

	TrafficPath = CreateDefaultSubobject<USplineComponent>(TEXT("TrafficPath"));
	TrafficPath->SetupAttachment(SceneRoot);
	TrafficPath->SetClosedLoop(false);

	PreviewRoot = CreateDefaultSubobject<USceneComponent>(TEXT("EditorPreviewRoot"));
	PreviewRoot->SetupAttachment(SceneRoot);
}

void ATrafficFlowManager::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	if (TrafficPath && TrafficPath->GetNumberOfSplinePoints() <= 2)
	{
		TrafficPath->ClearSplinePoints(false);
		TrafficPath->AddSplinePoint(FVector(-5000.0f, 0.0f, 0.0f), ESplineCoordinateSpace::Local, false);
		TrafficPath->AddSplinePoint(FVector(-2500.0f, 0.0f, 0.0f), ESplineCoordinateSpace::Local, false);
		TrafficPath->AddSplinePoint(FVector(0.0f, 0.0f, 0.0f), ESplineCoordinateSpace::Local, false);
		TrafficPath->AddSplinePoint(FVector(2500.0f, 0.0f, 0.0f), ESplineCoordinateSpace::Local, false);
		TrafficPath->AddSplinePoint(FVector(5000.0f, 0.0f, 0.0f), ESplineCoordinateSpace::Local, true);
		TrafficPath->SetClosedLoop(false);
	}

	BuildEditorPreview();
}

void ATrafficFlowManager::BeginPlay()
{
	Super::BeginPlay();

	if (bSpawnOnBeginPlay)
	{
		ClearEditorPreview();
		SpawnTraffic();
	}
}

void ATrafficFlowManager::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	AdvanceTraffic(DeltaSeconds);
}

void ATrafficFlowManager::AdvanceTraffic(float DeltaSeconds)
{
	if (!TrafficPath)
	{
		return;
	}

	const float SplineLength = TrafficPath->GetSplineLength();
	if (SplineLength <= 1.0f)
	{
		return;
	}

	UpdateDynamicSpeedVariation(DeltaSeconds);
	UpdateOvertaking(DeltaSeconds, SplineLength);
	UpdateAvoidanceSpeeds(DeltaSeconds, SplineLength);

	for (FRuntimeTrafficVehicle& RuntimeVehicle : RuntimeVehicles)
	{
		const float RequestedMove = RuntimeVehicle.Speed * DeltaSeconds;
		const float SafeMove = bUseFollowAvoidance
			? FMath::Min(RequestedMove, GetMaxMoveBeforeOverlap(RuntimeVehicle, SplineLength))
			: RequestedMove;
		RuntimeVehicle.Distance += FMath::Max(0.0f, SafeMove);
		if (bLoopTraffic)
		{
			RuntimeVehicle.Distance = FMath::Fmod(RuntimeVehicle.Distance, SplineLength);
		}
		else
		{
			if (RuntimeVehicle.Distance > SplineLength)
			{
				RuntimeVehicle.Distance = 0.0f;
			}
		}

		PlaceVehicle(RuntimeVehicle);
		if (ATrafficVehicleActor* TrafficVehicle = Cast<ATrafficVehicleActor>(RuntimeVehicle.Actor))
		{
			TrafficVehicle->UpdateWheelRotation(RuntimeVehicle.Speed, DeltaSeconds);
		}
	}
}

void ATrafficFlowManager::SpawnTraffic()
{
	ClearTraffic();

	UWorld* World = GetWorld();
	if (!World || !TrafficPath || VehicleTypes.Num() == 0)
	{
		return;
	}

	const float SplineLength = TrafficPath->GetSplineLength();
	const int32 SafeLaneCount = FMath::Max(1, LaneCount);
	const int32 PerLaneCount = FMath::Max(1, FMath::CeilToInt(static_cast<float>(InitialVehicleCount) / SafeLaneCount));
	const float BaseSpacing = SplineLength / PerLaneCount;
	TArray<float> LaneDistances;
	LaneDistances.Init(0.0f, SafeLaneCount);

	for (int32 VehicleIndex = 0; VehicleIndex < InitialVehicleCount; ++VehicleIndex)
	{
		const FTrafficVehicleType* Type = PickVehicleType(VehicleIndex);
		if (!Type)
		{
			continue;
		}

		TSubclassOf<AActor> SpawnClass = Type->VehicleClass;
		if (!SpawnClass)
		{
			SpawnClass = ATrafficVehicleActor::StaticClass();
		}

		const int32 LaneIndex = VehicleIndex % SafeLaneCount;
		const float RequiredSpacing = GetSpacingForVehicle(VehicleIndex, *Type, BaseSpacing);
		const float Distance = LaneDistances[LaneIndex] + LaneIndex * RequiredSpacing * 0.5f;
		if (Distance > SplineLength)
		{
			LaneDistances[LaneIndex] += RequiredSpacing;
			continue;
		}
		LaneDistances[LaneIndex] += RequiredSpacing;

		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AActor* Vehicle = World->SpawnActor<AActor>(SpawnClass, GetActorTransform(), Params);
		if (!Vehicle)
		{
			continue;
		}

		float RuntimeDesiredSpeed = GetSpeedForVehicle(VehicleIndex, *Type);
		if (ATrafficVehicleActor* TrafficVehicle = Cast<ATrafficVehicleActor>(Vehicle))
		{
			TrafficVehicle->VehicleLength = Type->VehicleLength;
			TrafficVehicle->DesiredSpeed = RuntimeDesiredSpeed;
			TrafficVehicle->ApplyVehicleMesh(Type->VehicleMesh, Type->VehicleScale);
		}

		FRuntimeTrafficVehicle RuntimeVehicle;
		RuntimeVehicle.Actor = Vehicle;
		RuntimeVehicle.Distance = Distance;
		RuntimeVehicle.DesiredSpeed = RuntimeDesiredSpeed;
		RuntimeVehicle.BaseDesiredSpeed = RuntimeDesiredSpeed;
		RuntimeVehicle.DynamicSpeedTimer = GetDynamicSpeedInterval(VehicleIndex, 0.0f);
		RuntimeVehicle.Speed = RuntimeDesiredSpeed;
		RuntimeVehicle.VehicleLength = Type->VehicleLength;
		RuntimeVehicle.LaneIndex = LaneIndex;
		RuntimeVehicle.HomeLaneIndex = LaneIndex;
		RuntimeVehicle.CurrentLanePosition = LaneIndex;
		RuntimeVehicle.LaneChangeYawOffset = 0.0f;
		RuntimeVehicle.OvertakeReturnTimer = 0.0f;
		RuntimeVehicle.OvertakeRetryTimer = 0.0f;
		PlaceVehicle(RuntimeVehicle);
		RuntimeVehicles.Add(RuntimeVehicle);
	}
}

void ATrafficFlowManager::ClearTraffic()
{
	for (FRuntimeTrafficVehicle& RuntimeVehicle : RuntimeVehicles)
	{
		if (RuntimeVehicle.Actor)
		{
			RuntimeVehicle.Actor->Destroy();
		}
	}
	RuntimeVehicles.Empty();
}

const FTrafficVehicleType* ATrafficFlowManager::PickVehicleType(int32 Index) const
{
	if (VehicleTypes.Num() == 0)
	{
		return nullptr;
	}

	float TotalWeight = 0.0f;
	for (const FTrafficVehicleType& Type : VehicleTypes)
	{
		TotalWeight += FMath::Max(0.0f, Type.SpawnWeight);
	}

	if (TotalWeight <= 0.0f)
	{
		return &VehicleTypes[Index % VehicleTypes.Num()];
	}

	const float Pick = FMath::Fmod(Index * 1.61803398875f, 1.0f) * TotalWeight;
	float Cursor = 0.0f;
	for (const FTrafficVehicleType& Type : VehicleTypes)
	{
		Cursor += FMath::Max(0.0f, Type.SpawnWeight);
		if (Pick <= Cursor)
		{
			return &Type;
		}
	}

	return &VehicleTypes.Last();
}

void ATrafficFlowManager::UpdateDynamicSpeedVariation(float DeltaSeconds)
{
	if (!bUseDynamicSpeedVariation)
	{
		for (FRuntimeTrafficVehicle& RuntimeVehicle : RuntimeVehicles)
		{
			RuntimeVehicle.DesiredSpeed = RuntimeVehicle.BaseDesiredSpeed;
		}
		return;
	}

	const float WorldTime = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.0f;
	for (int32 VehicleIndex = 0; VehicleIndex < RuntimeVehicles.Num(); ++VehicleIndex)
	{
		FRuntimeTrafficVehicle& RuntimeVehicle = RuntimeVehicles[VehicleIndex];
		RuntimeVehicle.DynamicSpeedTimer -= DeltaSeconds;
		if (RuntimeVehicle.DynamicSpeedTimer > 0.0f)
		{
			continue;
		}

		const float TimeSeed = WorldTime + VehicleIndex * 17.31f;
		RuntimeVehicle.DesiredSpeed = RuntimeVehicle.BaseDesiredSpeed * GetDynamicSpeedScale(VehicleIndex, TimeSeed);
		RuntimeVehicle.DynamicSpeedTimer = GetDynamicSpeedInterval(VehicleIndex, TimeSeed);
	}
}

void ATrafficFlowManager::UpdateOvertaking(float DeltaSeconds, float SplineLength)
{
	const int32 SafeLaneCount = FMath::Max(1, LaneCount);
	const float LateralSpeed = FMath::Max(0.1f, OvertakeLateralSpeed);
	if (!bUseOvertaking || SafeLaneCount <= 1 || RuntimeVehicles.Num() <= 1)
	{
		for (FRuntimeTrafficVehicle& RuntimeVehicle : RuntimeVehicles)
		{
			RuntimeVehicle.LaneIndex = FMath::Clamp(RuntimeVehicle.HomeLaneIndex, 0, SafeLaneCount - 1);
			UpdateLaneChangePose(RuntimeVehicle, DeltaSeconds);
		}
		return;
	}

	for (int32 VehicleIndex = 0; VehicleIndex < RuntimeVehicles.Num(); ++VehicleIndex)
	{
		FRuntimeTrafficVehicle& CurrentVehicle = RuntimeVehicles[VehicleIndex];
		CurrentVehicle.HomeLaneIndex = FMath::Clamp(CurrentVehicle.HomeLaneIndex, 0, SafeLaneCount - 1);
		CurrentVehicle.LaneIndex = FMath::Clamp(CurrentVehicle.LaneIndex, 0, SafeLaneCount - 1);
		CurrentVehicle.OvertakeRetryTimer = FMath::Max(0.0f, CurrentVehicle.OvertakeRetryTimer - DeltaSeconds);

		if (CurrentVehicle.LaneIndex != CurrentVehicle.HomeLaneIndex)
		{
			CurrentVehicle.OvertakeReturnTimer = FMath::Max(0.0f, CurrentVehicle.OvertakeReturnTimer - DeltaSeconds);
			if (CurrentVehicle.OvertakeReturnTimer <= 0.0f && IsLaneClearForOvertake(CurrentVehicle, CurrentVehicle.HomeLaneIndex, SplineLength))
			{
				CurrentVehicle.LaneIndex = CurrentVehicle.HomeLaneIndex;
			}
		}
		else
		{
			float NearestFrontDistance = TNumericLimits<float>::Max();
			float FrontSpeed = TNumericLimits<float>::Max();
			for (int32 OtherIndex = 0; OtherIndex < RuntimeVehicles.Num(); ++OtherIndex)
			{
				if (VehicleIndex == OtherIndex)
				{
					continue;
				}

				const FRuntimeTrafficVehicle& OtherVehicle = RuntimeVehicles[OtherIndex];
				if (OtherVehicle.LaneIndex != CurrentVehicle.LaneIndex)
				{
					continue;
				}

				const float FrontDistance = GetDistanceToFrontVehicle(CurrentVehicle, OtherVehicle, SplineLength);
				if (FrontDistance < NearestFrontDistance)
				{
					NearestFrontDistance = FrontDistance;
					FrontSpeed = OtherVehicle.Speed;
				}
			}

			const float BlockedSpeed = CurrentVehicle.DesiredSpeed * FMath::Clamp(OvertakeBlockedSpeedRatio, 0.05f, 1.0f);
			const bool bFrontIsClose = NearestFrontDistance < FMath::Max(0.0f, OvertakeLookAheadDistance);
			const bool bFrontIsSlow = FrontSpeed < BlockedSpeed;
			const bool bCurrentIsHeldUp = CurrentVehicle.Speed < BlockedSpeed;
			if (bFrontIsClose && (bFrontIsSlow || bCurrentIsHeldUp) && CurrentVehicle.OvertakeRetryTimer <= 0.0f)
			{
				CurrentVehicle.OvertakeRetryTimer = FMath::Max(0.0f, OvertakeRetryInterval);
				if (!ShouldAttemptOvertake(CurrentVehicle, VehicleIndex, SplineLength))
				{
					UpdateLaneChangePose(CurrentVehicle, DeltaSeconds);
					continue;
				}

				const int32 OvertakeLane = FindBestOvertakeLane(CurrentVehicle, SplineLength);
				if (OvertakeLane != INDEX_NONE)
				{
					CurrentVehicle.LaneIndex = OvertakeLane;
					CurrentVehicle.OvertakeReturnTimer = FMath::Max(0.0f, OvertakeReturnDelay);
				}
			}
		}

		UpdateLaneChangePose(CurrentVehicle, DeltaSeconds);
	}
}

void ATrafficFlowManager::UpdateAvoidanceSpeeds(float DeltaSeconds, float SplineLength)
{
	if (!bUseFollowAvoidance || RuntimeVehicles.Num() <= 1)
	{
		for (FRuntimeTrafficVehicle& RuntimeVehicle : RuntimeVehicles)
		{
			RuntimeVehicle.Speed = FMath::FInterpConstantTo(
				RuntimeVehicle.Speed,
				RuntimeVehicle.DesiredSpeed,
				DeltaSeconds,
				AccelerationRate);
		}
		return;
	}

	for (int32 VehicleIndex = 0; VehicleIndex < RuntimeVehicles.Num(); ++VehicleIndex)
	{
		FRuntimeTrafficVehicle& CurrentVehicle = RuntimeVehicles[VehicleIndex];
		float NearestFrontDistance = TNumericLimits<float>::Max();
		float FrontVehicleLength = 0.0f;

		for (int32 OtherIndex = 0; OtherIndex < RuntimeVehicles.Num(); ++OtherIndex)
		{
			if (VehicleIndex == OtherIndex)
			{
				continue;
			}

			const FRuntimeTrafficVehicle& OtherVehicle = RuntimeVehicles[OtherIndex];
			if (OtherVehicle.LaneIndex != CurrentVehicle.LaneIndex)
			{
				continue;
			}

			const float FrontDistance = GetDistanceToFrontVehicle(CurrentVehicle, OtherVehicle, SplineLength);
			if (FrontDistance < NearestFrontDistance)
			{
				NearestFrontDistance = FrontDistance;
				FrontVehicleLength = OtherVehicle.VehicleLength;
			}
		}

		const float StopDistance = CurrentVehicle.VehicleLength * 0.5f + FrontVehicleLength * 0.5f + MinimumGap;
		const float SlowDistance = StopDistance + FMath::Max(0.0f, SlowdownDistance);
		float TargetSpeed = CurrentVehicle.DesiredSpeed;

		if (NearestFrontDistance <= StopDistance)
		{
			TargetSpeed = 0.0f;
		}
		else if (NearestFrontDistance < SlowDistance)
		{
			const float Alpha = FMath::Clamp((NearestFrontDistance - StopDistance) / FMath::Max(1.0f, SlowDistance - StopDistance), 0.0f, 1.0f);
			TargetSpeed = CurrentVehicle.DesiredSpeed * Alpha;
		}

		const float ChangeRate = TargetSpeed < CurrentVehicle.Speed ? BrakingRate : AccelerationRate;
		CurrentVehicle.Speed = FMath::FInterpConstantTo(CurrentVehicle.Speed, TargetSpeed, DeltaSeconds, ChangeRate);
	}
}

float ATrafficFlowManager::GetDynamicSpeedScale(int32 VehicleIndex, float TimeSeed) const
{
	const float MinScale = FMath::Max(0.1f, FMath::Min(DynamicSpeedMin, DynamicSpeedMax));
	const float MaxScale = FMath::Max(MinScale, FMath::Max(DynamicSpeedMin, DynamicSpeedMax));
	const float Noise = FMath::Frac(FMath::Sin((VehicleIndex + 23) * 51.137f + TimeSeed * 9.271f) * 24634.6345f);
	return FMath::Lerp(MinScale, MaxScale, Noise);
}

float ATrafficFlowManager::GetDynamicSpeedInterval(int32 VehicleIndex, float TimeSeed) const
{
	const float MinInterval = FMath::Max(0.1f, FMath::Min(DynamicSpeedChangeIntervalMin, DynamicSpeedChangeIntervalMax));
	const float MaxInterval = FMath::Max(MinInterval, FMath::Max(DynamicSpeedChangeIntervalMin, DynamicSpeedChangeIntervalMax));
	const float Noise = FMath::Frac(FMath::Sin((VehicleIndex + 41) * 19.733f + TimeSeed * 5.119f) * 35718.923f);
	return FMath::Lerp(MinInterval, MaxInterval, Noise);
}

float ATrafficFlowManager::GetDistanceToFrontVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& FrontVehicle, float SplineLength) const
{
	float Distance = FrontVehicle.Distance - CurrentVehicle.Distance;
	if (bLoopTraffic && Distance < 0.0f)
	{
		Distance += SplineLength;
	}

	return Distance > 0.0f ? Distance : TNumericLimits<float>::Max();
}

float ATrafficFlowManager::GetDistanceToRearVehicle(const FRuntimeTrafficVehicle& CurrentVehicle, const FRuntimeTrafficVehicle& RearVehicle, float SplineLength) const
{
	float Distance = CurrentVehicle.Distance - RearVehicle.Distance;
	if (bLoopTraffic && Distance < 0.0f)
	{
		Distance += SplineLength;
	}

	return Distance > 0.0f ? Distance : TNumericLimits<float>::Max();
}

float ATrafficFlowManager::GetMaxMoveBeforeOverlap(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const
{
	float MaxMove = TNumericLimits<float>::Max();

	for (const FRuntimeTrafficVehicle& OtherVehicle : RuntimeVehicles)
	{
		if (&OtherVehicle == &CurrentVehicle || OtherVehicle.LaneIndex != CurrentVehicle.LaneIndex)
		{
			continue;
		}

		const float FrontDistance = GetDistanceToFrontVehicle(CurrentVehicle, OtherVehicle, SplineLength);
		if (FrontDistance == TNumericLimits<float>::Max())
		{
			continue;
		}

		const float StopDistance = CurrentVehicle.VehicleLength * 0.5f + OtherVehicle.VehicleLength * 0.5f + MinimumGap;
		const float AllowedMove = FrontDistance - StopDistance;
		MaxMove = FMath::Min(MaxMove, AllowedMove);
	}

	return MaxMove == TNumericLimits<float>::Max() ? TNumericLimits<float>::Max() : FMath::Max(0.0f, MaxMove);
}

bool ATrafficFlowManager::IsLaneClearForOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 CandidateLaneIndex, float SplineLength) const
{
	if (CandidateLaneIndex < 0 || CandidateLaneIndex >= FMath::Max(1, LaneCount))
	{
		return false;
	}

	const float Clearance = FMath::Max(MinimumGap, OvertakeLaneClearanceDistance);
	for (const FRuntimeTrafficVehicle& OtherVehicle : RuntimeVehicles)
	{
		if (&OtherVehicle == &CurrentVehicle || OtherVehicle.LaneIndex != CandidateLaneIndex)
		{
			continue;
		}

		const float RequiredGap = Clearance + CurrentVehicle.VehicleLength * 0.5f + OtherVehicle.VehicleLength * 0.5f;
		if (GetDistanceToFrontVehicle(CurrentVehicle, OtherVehicle, SplineLength) < RequiredGap)
		{
			return false;
		}

		if (GetDistanceToRearVehicle(CurrentVehicle, OtherVehicle, SplineLength) < RequiredGap)
		{
			return false;
		}
	}

	return true;
}

int32 ATrafficFlowManager::FindBestOvertakeLane(const FRuntimeTrafficVehicle& CurrentVehicle, float SplineLength) const
{
	const int32 SafeLaneCount = FMath::Max(1, LaneCount);
	const int32 RightLane = CurrentVehicle.LaneIndex + 1;
	const int32 LeftLane = CurrentVehicle.LaneIndex - 1;

	if (RightLane < SafeLaneCount && IsLaneClearForOvertake(CurrentVehicle, RightLane, SplineLength))
	{
		return RightLane;
	}

	if (LeftLane >= 0 && IsLaneClearForOvertake(CurrentVehicle, LeftLane, SplineLength))
	{
		return LeftLane;
	}

	return INDEX_NONE;
}

bool ATrafficFlowManager::ShouldAttemptOvertake(const FRuntimeTrafficVehicle& CurrentVehicle, int32 VehicleIndex, float SplineLength) const
{
	const float Chance = FMath::Clamp(OvertakeChance, 0.0f, 1.0f);
	if (Chance <= 0.0f)
	{
		return false;
	}

	if (Chance >= 1.0f)
	{
		return true;
	}

	const float DistanceSeed = SplineLength > 1.0f ? CurrentVehicle.Distance / SplineLength : CurrentVehicle.Distance * 0.001f;
	const float Noise = FMath::Frac(FMath::Sin((VehicleIndex + 101) * 37.719f + DistanceSeed * 173.31f + CurrentVehicle.Speed * 0.013f) * 91873.133f);
	return Noise <= Chance;
}

void ATrafficFlowManager::UpdateLaneChangePose(FRuntimeTrafficVehicle& RuntimeVehicle, float DeltaSeconds) const
{
	const float PreviousLanePosition = RuntimeVehicle.CurrentLanePosition;
	const float TargetLanePosition = static_cast<float>(RuntimeVehicle.LaneIndex);
	const float LateralSpeed = FMath::Max(0.1f, OvertakeLateralSpeed);
	RuntimeVehicle.CurrentLanePosition = FMath::FInterpConstantTo(
		RuntimeVehicle.CurrentLanePosition,
		TargetLanePosition,
		DeltaSeconds,
		LateralSpeed);

	const float LaneDeltaThisFrame = RuntimeVehicle.CurrentLanePosition - PreviousLanePosition;
	const float LaneDirection = FMath::IsNearlyZero(LaneDeltaThisFrame)
		? 0.0f
		: FMath::Sign(LaneDeltaThisFrame);
	const float LaneDistanceRemaining = TargetLanePosition - RuntimeVehicle.CurrentLanePosition;
	const float DesiredYawOffset = FMath::IsNearlyZero(LaneDirection)
		? 0.0f
		: LaneDirection * FMath::Clamp(FMath::Abs(LaneDistanceRemaining) * 2.0f, 0.0f, 1.0f) * OvertakeMaxSteeringYaw;

	RuntimeVehicle.LaneChangeYawOffset = FMath::FInterpTo(
		RuntimeVehicle.LaneChangeYawOffset,
		DesiredYawOffset,
		DeltaSeconds,
		FMath::Max(0.1f, OvertakeSteeringResponse));
}

void ATrafficFlowManager::PlaceVehicle(FRuntimeTrafficVehicle& RuntimeVehicle) const
{
	if (!RuntimeVehicle.Actor || !TrafficPath)
	{
		return;
	}

	const float LaneOffset = (RuntimeVehicle.CurrentLanePosition - (LaneCount - 1) * 0.5f) * LaneSpacing;
	const float SampleDistance = GetSplineSampleDistance(RuntimeVehicle.Distance);
	const FVector SplineLocation = TrafficPath->GetLocationAtDistanceAlongSpline(SampleDistance, ESplineCoordinateSpace::World)
		+ GetLaneRightVectorAtDistance(SampleDistance) * LaneOffset
		+ FVector(0.0f, 0.0f, VehicleZOffset);
	const FVector Location = ProjectToTerrain(SplineLocation, RuntimeVehicle.Actor);
	const FRotator Rotation = GetPathYawRotation(SampleDistance);
	FRotator SteeredRotation = Rotation;
	SteeredRotation.Yaw += bReverseTrafficDirection ? -RuntimeVehicle.LaneChangeYawOffset : RuntimeVehicle.LaneChangeYawOffset;

	RuntimeVehicle.Actor->SetActorLocationAndRotation(Location, SteeredRotation, false, nullptr, ETeleportType::TeleportPhysics);
}

FVector ATrafficFlowManager::GetLaneRightVectorAtDistance(float Distance) const
{
	const FVector Direction = TrafficPath
		? TrafficPath->GetDirectionAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World)
		: FVector::ForwardVector;
	return FVector::CrossProduct(FVector::UpVector, Direction).GetSafeNormal();
}

float ATrafficFlowManager::GetSpacingForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type, float BaseSpacing) const
{
	const float MinimumSafeSpacing = Type.VehicleLength + MinimumGap;
	const float SafeSpacing = FMath::Max(MinimumSafeSpacing, BaseSpacing);
	if (!bUseRandomSpacing)
	{
		return SafeSpacing;
	}

	const float MinScale = FMath::Max(0.1f, FMath::Min(RandomSpacingMin, RandomSpacingMax));
	const float MaxScale = FMath::Max(MinScale, FMath::Max(RandomSpacingMin, RandomSpacingMax));
	const float Noise = FMath::Frac(FMath::Sin((VehicleIndex + 3) * 12.9898f) * 43758.5453f);
	return FMath::Max(MinimumSafeSpacing, SafeSpacing * FMath::Lerp(MinScale, MaxScale, Noise));
}

float ATrafficFlowManager::GetSpeedForVehicle(int32 VehicleIndex, const FTrafficVehicleType& Type) const
{
	if (!bUseRandomSpeed)
	{
		return Type.DesiredSpeed;
	}

	const float MinScale = FMath::Max(0.1f, FMath::Min(RandomSpeedMin, RandomSpeedMax));
	const float MaxScale = FMath::Max(MinScale, FMath::Max(RandomSpeedMin, RandomSpeedMax));
	const float Noise = FMath::Frac(FMath::Sin((VehicleIndex + 11) * 78.233f) * 19341.113f);
	return Type.DesiredSpeed * FMath::Lerp(MinScale, MaxScale, Noise);
}

float ATrafficFlowManager::GetSplineSampleDistance(float Distance) const
{
	if (!TrafficPath || !bReverseTrafficDirection)
	{
		return Distance;
	}

	return FMath::Max(0.0f, TrafficPath->GetSplineLength() - Distance);
}

FRotator ATrafficFlowManager::GetPathYawRotation(float Distance) const
{
	if (!TrafficPath)
	{
		return FRotator::ZeroRotator;
	}

	FVector Direction = TrafficPath->GetDirectionAtDistanceAlongSpline(Distance, ESplineCoordinateSpace::World);
	Direction.Z = 0.0f;
	if (Direction.IsNearlyZero())
	{
		Direction = FVector::ForwardVector;
	}

	float Yaw = Direction.Rotation().Yaw;
	if (bReverseTrafficDirection)
	{
		Yaw += 180.0f;
	}

	return FRotator(0.0f, Yaw, 0.0f);
}

FVector ATrafficFlowManager::ProjectToTerrain(const FVector& Location, const AActor* ActorToIgnore) const
{
	if (!bUseTerrainDetection)
	{
		return Location;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return Location;
	}

	const FVector Start = Location + FVector(0.0f, 0.0f, TerrainTraceStartHeight);
	const FVector End = Location - FVector(0.0f, 0.0f, TerrainTraceEndDepth);
	FHitResult Hit;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(TrafficTerrainTrace), true, this);
	if (ActorToIgnore)
	{
		Params.AddIgnoredActor(ActorToIgnore);
	}
	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic, Params))
	{
		return Hit.ImpactPoint + FVector(0.0f, 0.0f, TerrainZOffset);
	}

	return Location;
}

void ATrafficFlowManager::BuildEditorPreview()
{
	if (GetWorld() && GetWorld()->IsGameWorld())
	{
		return;
	}

	ClearEditorPreview();

	if (!bShowEditorPreview || !PreviewRoot || !TrafficPath || VehicleTypes.Num() == 0)
	{
		return;
	}

	const float SplineLength = TrafficPath->GetSplineLength();
	if (SplineLength <= 1.0f)
	{
		return;
	}

	const int32 SafeLaneCount = FMath::Max(1, LaneCount);
	const int32 PerLaneCount = FMath::Max(1, FMath::CeilToInt(static_cast<float>(InitialVehicleCount) / SafeLaneCount));
	const float BaseSpacing = SplineLength / PerLaneCount;
	TArray<float> LaneDistances;
	LaneDistances.Init(0.0f, SafeLaneCount);

	for (int32 VehicleIndex = 0; VehicleIndex < InitialVehicleCount; ++VehicleIndex)
	{
		const FTrafficVehicleType* Type = PickVehicleType(VehicleIndex);
		if (!Type || !Type->VehicleMesh)
		{
			continue;
		}

		const int32 LaneIndex = VehicleIndex % SafeLaneCount;
		const float RequiredSpacing = GetSpacingForVehicle(VehicleIndex, *Type, BaseSpacing);
		const float Distance = LaneDistances[LaneIndex] + LaneIndex * RequiredSpacing * 0.5f;
		if (Distance > SplineLength)
		{
			LaneDistances[LaneIndex] += RequiredSpacing;
			continue;
		}
		LaneDistances[LaneIndex] += RequiredSpacing;

		UStaticMeshComponent* PreviewMesh = NewObject<UStaticMeshComponent>(this, UStaticMeshComponent::StaticClass(), *FString::Printf(TEXT("PreviewVehicle_%02d"), VehicleIndex + 1));
		PreviewMesh->SetupAttachment(PreviewRoot);
		PreviewMesh->SetStaticMesh(Type->VehicleMesh);
		PreviewMesh->SetRelativeScale3D(Type->VehicleScale);
		PreviewMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		PreviewMesh->SetMobility(EComponentMobility::Movable);
		PreviewMesh->RegisterComponent();
		AddInstanceComponent(PreviewMesh);

		const float LaneOffset = (LaneIndex - (SafeLaneCount - 1) * 0.5f) * LaneSpacing;
		const float SampleDistance = GetSplineSampleDistance(Distance);
		const FVector Location = ProjectToTerrain(
			TrafficPath->GetLocationAtDistanceAlongSpline(SampleDistance, ESplineCoordinateSpace::World)
			+ GetLaneRightVectorAtDistance(SampleDistance) * LaneOffset
			+ FVector(0.0f, 0.0f, VehicleZOffset),
			this);
		const FRotator Rotation = GetPathYawRotation(SampleDistance);
		PreviewMesh->SetWorldLocationAndRotation(Location, Rotation);

		PreviewVehicleMeshes.Add(PreviewMesh);
	}
}

void ATrafficFlowManager::ClearEditorPreview()
{
	TArray<UActorComponent*> ComponentsToRemove;
	for (UActorComponent* Component : GetInstanceComponents())
	{
		if (Component && Component->GetName().StartsWith(TEXT("PreviewVehicle_")))
		{
			ComponentsToRemove.Add(Component);
		}
	}

	for (UStaticMeshComponent* PreviewMesh : PreviewVehicleMeshes)
	{
		if (PreviewMesh)
		{
			ComponentsToRemove.AddUnique(PreviewMesh);
		}
	}

	for (UActorComponent* Component : ComponentsToRemove)
	{
		if (Component)
		{
			RemoveInstanceComponent(Component);
			Component->DestroyComponent();
		}
	}

	PreviewVehicleMeshes.Empty();
}
