# Traffic Flow Plugin / 车流插件说明

UE version / UE版本: Unreal Engine 5.7  
Plugin folder / 插件目录: `TrafficFlow`

## 中文说明

### 1. 插件用途

Traffic Flow 是一个基于样条线的车流插件。它可以在关卡中沿 Spline 自动生成车辆，让车辆沿样条线行驶，并支持车辆替换、防止重叠、跟车减速、随机速度、动态速度变化、地形检测、编辑器预览和轮子旋转。

插件核心蓝图/类：

- `BP_TrafficFlowManager`: 车流管理器，放到场景里使用。
- `BP_TrafficVehicle_Sedan`: 示例轿车。
- `BP_TrafficVehicle_Van`: 示例面包车。
- `BP_TrafficVehicle_Truck`: 示例卡车。
- `TrafficVehicleActor`: 可继承的车辆基类。

### 2. 安装方法

将插件文件夹复制到目标项目：

```text
YourProject/Plugins/TrafficFlow/TrafficFlow.uplugin
```

正确结构应该是：

```text
YourProject
  Plugins
    TrafficFlow
      TrafficFlow.uplugin
      Binaries
      Content
      Source
```

复制完成后：

1. 打开 UE5.7 项目。
2. 打开 `Edit > Plugins`。
3. 搜索 `Traffic Flow`。
4. 启用插件。
5. 按提示重启编辑器。

如果内容浏览器里看不到插件内容：

1. 打开 Content Browser 右上角设置。
2. 勾选 `Show Plugin Content` / `显示插件内容`。
3. 在 `All > Plugins > TrafficFlow` 下查找蓝图。
4. 也可以直接搜索 `BP_TrafficFlowManager`。

### 3. 快速使用

1. 在内容浏览器中找到 `BP_TrafficFlowManager`。
2. 拖入关卡。
3. 选中场景中的 `BP_TrafficFlowManager`。
4. 在细节面板调整 `TrafficPath` 样条线点。
5. 设置车辆数量、车道数量、速度、间距等参数。
6. 点击播放，车辆会沿样条线移动。

默认样条线是不闭合的。如果需要循环车流，开启 `Loop Traffic`。

### 4. 路径和方向

车辆沿 `TrafficPath` 样条线移动。移动方向由样条线点的顺序决定。

常用参数：

- `Loop Traffic`: 到达终点后循环回起点。
- `Reverse Traffic Direction`: 反向行驶。
- `VehicleZOffset`: 车辆相对样条线的高度偏移，默认 `0`。
- `Lane Count`: 车道数量。
- `Lane Spacing`: 车道间距。

如果车辆方向反了，优先切换 `Reverse Traffic Direction`。

如果车辆悬空或埋入地面，调整 `VehicleZOffset` 或开启地形检测后调整 `TerrainZOffset`。

### 5. 替换车辆

在 `BP_TrafficFlowManager` 的 `Vehicle Types` 中添加或修改车辆类型。

每个车辆类型包含：

- `Name`: 车辆类型名称。
- `Vehicle Class`: 要生成的车辆 Actor 蓝图类。
- `Vehicle Mesh`: 使用插件默认车辆基类时，可替换静态网格。
- `Vehicle Scale`: 车辆缩放，默认建议保持 `1, 1, 1`。
- `Vehicle Length`: 车辆长度，用于间距和防重叠计算。
- `Desired Speed`: 目标速度。
- `Spawn Weight`: 生成权重。

`Vehicle Class` 现在可以选择任意 `Actor` 蓝图类。  
如果该蓝图继承自 `TrafficVehicleActor`，插件会额外支持自动换 Mesh、轮子旋转、车辆长度和速度参数同步。  
如果是普通 Actor 蓝图，插件会移动整个 Actor，但不会自动替换 Mesh，也不会自动识别 `TrafficVehicleActor` 的车辆参数。

### 6. 防止车辆重叠

插件通过跟车避让系统避免车辆重叠。

相关参数：

- `Use Follow Avoidance`: 启用跟车避让。
- `Minimum Gap`: 车辆之间的最小间距。
- `Slowdown Distance`: 前方车辆进入该范围后开始减速。
- `Braking Rate`: 刹车速度。
- `Acceleration Rate`: 恢复加速速度。

建议保持 `Use Follow Avoidance` 开启。  
如果车辆仍然太近，增大 `Minimum Gap` 或 `Slowdown Distance`。  
如果减速太慢，增大 `Braking Rate`。

### 7. 随机间距和随机速度

生成时随机：

- `Use Random Spacing`: 每辆车生成间距随机。
- `Random Spacing Min / Max`: 间距倍率范围。
- `Use Random Speed`: 每辆车生成时速度随机。
- `Random Speed Min / Max`: 初始速度倍率范围。

运行中随机变速：

- `Use Dynamic Speed Variation`: 启用单车运行中随机变速。
- `Dynamic Speed Min / Max`: 动态速度倍率范围。
- `Dynamic Speed Change Interval Min / Max`: 每辆车随机换速度的时间间隔。

示例：  
`Dynamic Speed Min = 0.75`，`Dynamic Speed Max = 1.25` 表示车辆运行中会在基础速度的 75% 到 125% 之间变化。

### 8. 地形检测

地形检测可以让车辆贴合地面高度。

相关参数：

- `Use Terrain Detection`: 开启地形检测。
- `Terrain Trace Start Height`: 向上追踪起点高度。
- `Terrain Trace End Depth`: 向下追踪深度。
- `TerrainZOffset`: 命中地面后的高度偏移，默认 `0`。

如果车辆只需要严格贴合样条线，可以关闭地形检测。  
如果场景有起伏地形，可以开启地形检测。

### 9. 编辑器预览

`Show Editor Preview` 开启后，不运行游戏也能看到大致车辆分布。

注意：

- 编辑器预览主要用于查看位置和密度。
- 预览使用 `Vehicle Mesh` 显示静态车辆。
- 运行时如果使用的是自定义 `Vehicle Class`，实际生成结果以运行时为准。

### 10. 轮子旋转

车辆蓝图继承自 `TrafficVehicleActor` 时，可以使用自动轮子旋转。

参数位于车辆蓝图的 `Wheels` 分类：

- `Animate Wheels`: 开启轮子旋转。
- `Auto Find Wheel Components`: 自动查找轮子组件。
- `Wheel Components`: 手动指定轮子组件，可选。
- `Wheel Radius`: 轮子半径，影响转速。
- `Wheel Rotation Axis`: 轮子旋转轴。
- `Invert Wheel Rotation`: 轮子转反时启用。

推荐用法：

1. 车辆蓝图继承 `TrafficVehicleActor`。
2. 车身为主 `VehicleMesh`。
3. 四个轮子是独立的 Static Mesh 子组件。
4. 保持 `Animate Wheels` 和 `Auto Find Wheel Components` 开启。
5. 播放测试。

如果轮子转反，开启 `Invert Wheel Rotation`。  
如果轮子绕错轴旋转，尝试以下轴：

```text
0, 1, 0
1, 0, 0
0, 0, 1
```

如果车辆是一个完整的单体 Static Mesh，车轮没有独立组件，则插件不能单独旋转轮子。需要将车身和轮子拆成独立组件，或使用带骨骼/动画的车辆蓝图。

### 11. 普通车辆 Actor 和 Cinematic Car Rig

`Vehicle Class` 可以选择普通 Actor，例如 Cinematic Car Rig 蓝图。  
这种情况下，插件会沿样条线移动整个 Actor。

需要注意：

- 普通 Actor 不会自动应用 `Vehicle Mesh`。
- 普通 Actor 不会自动使用 `TrafficVehicleActor` 的轮子旋转参数。
- 如果该 Actor 自带动画或车轮控制，需要在自己的蓝图里处理。
- 插件提供 `OnTrafficMovementUpdated` 事件给 `TrafficVehicleActor` 子类使用，复杂蓝图可以在该事件中驱动车轮动画。

### 12. 常见问题

#### 插件启用了，但内容里没有 TrafficFlow 文件夹

开启 `Show Plugin Content` / `显示插件内容`。插件内容不会默认显示在项目 `/Game` 内容中，而是在插件内容目录下。

#### 车辆不显示

检查：

- `Vehicle Types` 是否至少有一个元素。
- `Vehicle Class` 是否有效。
- 如果使用预览，是否设置了 `Vehicle Mesh`。
- 运行时是否开启了 `Spawn On Begin Play`。
- 车辆蓝图本身是否有可见 Mesh。

#### 车辆方向不对

尝试开启或关闭 `Reverse Traffic Direction`。  
也可以调整样条线点的顺序。

#### 车辆往 Z 轴飞

确保车辆 Mesh 不使用物理模拟。插件默认车辆基类会禁用碰撞和物理。  
如果使用自定义车辆蓝图，建议关闭车辆主体的物理模拟，避免与场景碰撞后被物理推飞。

#### 车辆重叠

开启 `Use Follow Avoidance`。  
增大 `Minimum Gap`、`Slowdown Distance` 或 `Braking Rate`。  
同时确认 `Vehicle Length` 接近实际车辆长度。

#### 轮子不转

检查：

- 车辆是否继承自 `TrafficVehicleActor`。
- `Animate Wheels` 是否开启。
- 是否有独立轮子 Static Mesh 组件。
- `Auto Find Wheel Components` 是否开启。
- `Wheel Radius` 是否合理。

#### 轮子转得太快或太慢

调整 `Wheel Radius`。  
半径越大，转得越慢；半径越小，转得越快。

### 13. 参数建议

普通道路：

```text
Initial Vehicle Count: 20
Lane Count: 2
Lane Spacing: 420
Minimum Gap: 280
Desired Speed: 900
Slowdown Distance: 1200
Acceleration Rate: 650
Braking Rate: 2200
```

密集车流：

```text
Minimum Gap: 180 - 260
Slowdown Distance: 800 - 1200
Braking Rate: 2500 - 3500
Use Dynamic Speed Variation: true
Dynamic Speed Min: 0.75
Dynamic Speed Max: 1.15
```

更自然的车流：

```text
Use Random Spacing: true
Random Spacing Min: 0.85
Random Spacing Max: 1.25
Use Random Speed: true
Random Speed Min: 0.85
Random Speed Max: 1.15
Use Dynamic Speed Variation: true
```

### 14. Overtaking / Lane Change Passing

Version 1.1.0 adds a runtime overtaking system. When a vehicle is held up by a slow or stopped vehicle ahead, it checks adjacent lanes. If the side lane has enough front and rear clearance, the vehicle changes lanes smoothly, passes the blockage, waits briefly, and then returns to its original lane when safe.

New settings on `BP_TrafficFlowManager`:

- `Use Overtaking`: Enables lane-change overtaking.
- `Overtake Look Ahead Distance`: How far ahead a vehicle checks for a slow blocker.
- `Overtake Blocked Speed Ratio`: A front vehicle below this fraction of the follower desired speed counts as blocked traffic.
- `Overtake Chance`: Probability that a vehicle will attempt overtaking after the road ahead is blocked and a side lane is available.
- `Overtake Retry Interval`: Cooldown before the same vehicle rolls another overtaking attempt.
- `Overtake Lane Clearance Distance`: Required clear distance in the target lane, both ahead and behind.
- `Overtake Lateral Speed`: Lane-change interpolation speed. Higher values change lanes faster.
- `Overtake Max Steering Yaw`: Maximum temporary steering angle while changing lanes.
- `Overtake Steering Response`: How quickly the vehicle points into the lane change and returns straight.
- `Overtake Return Delay`: Minimum time to stay in the passing lane before trying to return.

Recommended starting values:

```text
Use Overtaking: true
Overtake Look Ahead Distance: 900
Overtake Blocked Speed Ratio: 0.55
Overtake Chance: 0.65
Overtake Retry Interval: 1.25
Overtake Lane Clearance Distance: 850
Overtake Lateral Speed: 2.5
Overtake Max Steering Yaw: 14
Overtake Steering Response: 7
Overtake Return Delay: 1.5
```

For busy traffic, increase `Overtake Lane Clearance Distance` to reduce close cut-ins. For more aggressive traffic, lower it slightly and increase `Overtake Lateral Speed`. Lower `Overtake Chance` if too many vehicles overtake; raise it toward `1.0` if almost every capable vehicle should pass. If lane changes still look too flat, increase `Overtake Max Steering Yaw`; if the heading snaps too fast, lower `Overtake Steering Response`.

## English Guide

### 1. Overview

Traffic Flow is a spline-based traffic plugin for Unreal Engine 5.7. It spawns vehicles along a spline path, moves them along the route, and supports replaceable vehicles, no-overlap following behavior, random spacing, random speed, dynamic speed variation, terrain projection, editor preview, and wheel rotation.

Main assets/classes:

- `BP_TrafficFlowManager`: Place this actor in the level to create traffic.
- `BP_TrafficVehicle_Sedan`: Example sedan vehicle.
- `BP_TrafficVehicle_Van`: Example van vehicle.
- `BP_TrafficVehicle_Truck`: Example truck vehicle.
- `TrafficVehicleActor`: Base vehicle class for custom traffic vehicles.

### 2. Installation

Copy the plugin folder into your project:

```text
YourProject/Plugins/TrafficFlow/TrafficFlow.uplugin
```

The correct folder layout is:

```text
YourProject
  Plugins
    TrafficFlow
      TrafficFlow.uplugin
      Binaries
      Content
      Source
```

Then:

1. Open the UE5.7 project.
2. Open `Edit > Plugins`.
3. Search for `Traffic Flow`.
4. Enable the plugin.
5. Restart the editor when prompted.

If you cannot see the plugin assets in the Content Browser:

1. Open the Content Browser settings.
2. Enable `Show Plugin Content`.
3. Look under `All > Plugins > TrafficFlow`.
4. You can also search for `BP_TrafficFlowManager`.

### 3. Quick Start

1. Find `BP_TrafficFlowManager` in the Content Browser.
2. Drag it into the level.
3. Select it in the level.
4. Edit the `TrafficPath` spline points.
5. Set vehicle count, lanes, speed, and spacing.
6. Press Play. Vehicles will move along the spline.

The default spline is open, not closed. Enable `Loop Traffic` if you want vehicles to loop back to the start.

### 4. Path and Direction

Vehicles follow the `TrafficPath` spline. The movement direction is based on the spline point order.

Common settings:

- `Loop Traffic`: Wrap vehicles back to the start when they reach the end.
- `Reverse Traffic Direction`: Reverse vehicle movement direction.
- `VehicleZOffset`: Height offset from the spline, default `0`.
- `Lane Count`: Number of lanes.
- `Lane Spacing`: Distance between lanes.

If vehicles face the wrong direction, toggle `Reverse Traffic Direction`.  
If vehicles float or sink, adjust `VehicleZOffset`, or use terrain detection and adjust `TerrainZOffset`.

### 5. Replacing Vehicles

Edit `Vehicle Types` on `BP_TrafficFlowManager`.

Each vehicle type contains:

- `Name`: Vehicle type name.
- `Vehicle Class`: Actor blueprint class to spawn.
- `Vehicle Mesh`: Static mesh used by the default traffic vehicle base class.
- `Vehicle Scale`: Vehicle scale. Keeping `1, 1, 1` is recommended.
- `Vehicle Length`: Used for spacing and no-overlap calculations.
- `Desired Speed`: Target movement speed.
- `Spawn Weight`: Spawn probability weight.

`Vehicle Class` accepts any `Actor` blueprint class.  
If the class inherits from `TrafficVehicleActor`, the plugin can also apply mesh replacement, wheel animation, vehicle length, and speed settings.  
If it is a regular Actor, the plugin moves the whole Actor along the spline, but it will not automatically apply `Vehicle Mesh` or `TrafficVehicleActor` features.

### 6. Avoiding Overlap

The plugin includes a follow-avoidance system.

Settings:

- `Use Follow Avoidance`: Enables follow avoidance.
- `Minimum Gap`: Minimum distance between vehicles.
- `Slowdown Distance`: Distance at which a vehicle starts slowing down behind another vehicle.
- `Braking Rate`: How quickly vehicles slow down.
- `Acceleration Rate`: How quickly vehicles accelerate back to target speed.

Keep `Use Follow Avoidance` enabled for normal use.  
If vehicles are too close, increase `Minimum Gap` or `Slowdown Distance`.  
If braking is too slow, increase `Braking Rate`.

### 7. Random Spacing and Speed

Spawn-time randomization:

- `Use Random Spacing`: Randomizes initial spacing.
- `Random Spacing Min / Max`: Spacing multiplier range.
- `Use Random Speed`: Randomizes initial vehicle speed.
- `Random Speed Min / Max`: Initial speed multiplier range.

Runtime dynamic speed variation:

- `Use Dynamic Speed Variation`: Enables per-vehicle runtime speed changes.
- `Dynamic Speed Min / Max`: Runtime speed multiplier range.
- `Dynamic Speed Change Interval Min / Max`: Random time interval before each vehicle picks a new target speed.

Example:  
`Dynamic Speed Min = 0.75` and `Dynamic Speed Max = 1.25` means each vehicle can vary between 75% and 125% of its base speed while running.

### 8. Terrain Detection

Terrain detection projects vehicles onto ground height.

Settings:

- `Use Terrain Detection`: Enables ground projection.
- `Terrain Trace Start Height`: Trace start height above the vehicle position.
- `Terrain Trace End Depth`: Trace depth below the vehicle position.
- `TerrainZOffset`: Height offset after a ground hit, default `0`.

Keep it off if vehicles should strictly follow the spline height.  
Enable it for uneven terrain.

### 9. Editor Preview

Enable `Show Editor Preview` to see approximate vehicle placement without pressing Play.

Notes:

- Editor preview is for layout and density checking.
- Preview uses `Vehicle Mesh`.
- Runtime spawning may differ if you use a custom `Vehicle Class`.

### 10. Wheel Rotation

Vehicles that inherit from `TrafficVehicleActor` can use automatic wheel rotation.

Settings on the vehicle blueprint:

- `Animate Wheels`: Enables wheel rotation.
- `Auto Find Wheel Components`: Automatically finds wheel components.
- `Wheel Components`: Optional manual wheel component list.
- `Wheel Radius`: Wheel radius. This affects rotation speed.
- `Wheel Rotation Axis`: Local wheel rotation axis.
- `Invert Wheel Rotation`: Enable if wheels spin backward.

Recommended setup:

1. Inherit the vehicle blueprint from `TrafficVehicleActor`.
2. Use `VehicleMesh` as the main body mesh.
3. Add four independent Static Mesh components for the wheels.
4. Keep `Animate Wheels` and `Auto Find Wheel Components` enabled.
5. Press Play to test.

If wheels spin backward, enable `Invert Wheel Rotation`.  
If they rotate around the wrong axis, try:

```text
0, 1, 0
1, 0, 0
0, 0, 1
```

If the vehicle is a single static mesh with wheels merged into the body, the plugin cannot rotate the wheels separately. Split the wheels into separate components or use a skeletal/animated vehicle blueprint.

### 11. Regular Actors and Cinematic Car Rig

`Vehicle Class` can be a regular Actor, including a Cinematic Car Rig blueprint.  
In this case, the plugin moves the whole Actor along the spline.

Notes:

- Regular Actors do not automatically use `Vehicle Mesh`.
- Regular Actors do not automatically use `TrafficVehicleActor` wheel settings.
- If the Actor has its own wheel animation or rig logic, handle it inside that blueprint.
- `TrafficVehicleActor` subclasses can use the `OnTrafficMovementUpdated` event for custom animation logic.

### 12. FAQ

#### The plugin is enabled, but I cannot see the TrafficFlow folder

Enable `Show Plugin Content` in the Content Browser. Plugin assets are stored under plugin content, not under the project `/Game` folder by default.

#### Vehicles do not appear

Check:

- `Vehicle Types` has at least one entry.
- `Vehicle Class` is valid.
- `Vehicle Mesh` is assigned if you rely on editor preview.
- `Spawn On Begin Play` is enabled for runtime spawning.
- The vehicle blueprint has a visible mesh.

#### Vehicles face the wrong direction

Toggle `Reverse Traffic Direction`, or change the spline point order.

#### Vehicles fly upward on collision

Disable physics simulation on custom vehicle meshes. The default plugin vehicle class disables collision and physics to avoid physics impulses.

#### Vehicles overlap

Enable `Use Follow Avoidance`.  
Increase `Minimum Gap`, `Slowdown Distance`, or `Braking Rate`.  
Make sure `Vehicle Length` roughly matches the real vehicle length.

#### Wheels do not rotate

Check:

- The vehicle inherits from `TrafficVehicleActor`.
- `Animate Wheels` is enabled.
- The wheels are independent Static Mesh components.
- `Auto Find Wheel Components` is enabled.
- `Wheel Radius` is reasonable.

#### Wheels spin too fast or too slowly

Adjust `Wheel Radius`.  
A larger radius makes wheels spin slower. A smaller radius makes them spin faster.

### 13. Suggested Settings

Normal road:

```text
Initial Vehicle Count: 20
Lane Count: 2
Lane Spacing: 420
Minimum Gap: 280
Desired Speed: 900
Slowdown Distance: 1200
Acceleration Rate: 650
Braking Rate: 2200
```

Dense traffic:

```text
Minimum Gap: 180 - 260
Slowdown Distance: 800 - 1200
Braking Rate: 2500 - 3500
Use Dynamic Speed Variation: true
Dynamic Speed Min: 0.75
Dynamic Speed Max: 1.15
```

More natural traffic:

```text
Use Random Spacing: true
Random Spacing Min: 0.85
Random Spacing Max: 1.25
Use Random Speed: true
Random Speed Min: 0.85
Random Speed Max: 1.15
Use Dynamic Speed Variation: true
```
